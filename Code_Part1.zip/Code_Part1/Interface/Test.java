package pack1;
 
public class A
{
    private int methodOne(int i)
    {
        return ++i;
    }
     
    public int methodTwo(int i)
    {
        return methodOne(++i);
    }
}
 
package pack2;
 
import pack1.A;
 
class B extends A
{
    int methodOne(int i)
    {
        return methodTwo(++i);
    }
}
 
public class Test
{
    public static void main(String[] args)
    {
        System.out.println(new B().methodOne(101));
    }
}

