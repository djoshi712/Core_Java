interface Interf
{
	void m1();
	void m2();
}
 class ServiceProvider implements Interf
{
	public void m1()
	{
	}
}