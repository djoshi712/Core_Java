class Test
{
public static void main(String args[])
{
doStuff();
}
public static void doStuff()
{
domMoreStuff();
}
public static void domMoreStuff()
{
System.out.println("Hello");
}
}
