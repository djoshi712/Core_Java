
class Ex7
{
	public static void main(String[] args) 
	{	
	//int i= Integer.parseInt("10");
	int j= Integer.parseInt("ten");
	}
}
