
class Ex5
{             
	public static void main(String[] args) 
	{		
		String s= new String("java");
		Object o= (Object)s;
		Object o1= new Object();
		String s1= (String)o1;
		
	}
}
