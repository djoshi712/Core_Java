
class Ex6
{
	public static void main(String[] args) 
	{	
		Thread t= new Thread();
		//t.setPriority(7);
		t.setPriority(11);
	}
}
