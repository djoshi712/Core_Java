
import java.io.*;

class Checked {  
   public static void main(String args[]) throws FileNotFoundException, IOException
   {
	FileInputStream obj = new FileInputStream("D:/city.txt"); 
	int k; 
	
	while(( k = obj.read() ) != -1) 
	{ 
		System.out.print((char)k); 
	} 
	obj.close(); 	
   }
}
