//finally
class Finaly{  
  public static void main(String args[]){  
  try{  
    int arr[] ={1,2,3,4,5};
	System.out.println(arr[7]);   
  }  
  catch(Exception e)
  {
	  System.out.println(e);
  }  
  catch(ArrayIndexOutOfBoundsException e)
  {
	  System.out.println(e);
  }
  finally
  {
	  System.out.println("finally block is always executed");}    
  }  
}  

	
	