class Testing1
{
  // some code
}
class Ex4
{
    public static void main(String[] args)
    {
        Testing1 a = new Testing1();
    }
}
