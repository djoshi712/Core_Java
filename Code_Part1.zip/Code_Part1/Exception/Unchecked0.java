//unchecked exception
class Unchecked {  
   public static void main(String args[]) 
   {
	int num1=10;
	int num2=0;
	int res=num1/num2;
	System.out.println(10/0);
	System.out.println("fjkdshf");
   }
}
//whether it is checked or unchecked, every exception 
//occur at runtime. there is no chance of occuring any 
//exception at compile time
