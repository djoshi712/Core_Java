/*  class A
{
	public static void main(String[] args)
	{
		throw new ArithmeticException();
		System.out.println("hello");		
	}
} */ 
 class Test
{
	public static void main(String[] args)
	{
		//throw new Test();
		throw new New();
	}
} 
 
