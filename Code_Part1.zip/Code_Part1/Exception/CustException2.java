import java.util.Scanner;
class TooYoungException extends Exception 
{
	TooYoungException(String s)
	{
		super(s);
	}
}
class TooOldException extends Exception 
{
	TooOldException(String s)
	{
		super(s);
	}
}
class CustException2
{
	public static void main(String args[]) throws TooOldException, TooYoungException
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your age");
		int age=sc.nextInt();
		if(age>60)
		{
			try
			{
			throw new TooOldException("you have already crossed marriage age and no chance of getting married");
		}
		else if(age<18)
		{
		    throw new TooYoungException("very eager to marry haan! wait for some time");
		}
		else 
		{
			System.out.println("welcome");
		}
	}
}
	