// throws

class Test9
{
	public static void main(String[] args) throws InterruptedException
	{		System.out.println("Hello");
			Thread.sleep(10000);
			System.out.println("Hi");
}	}
