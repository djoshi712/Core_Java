//without try catch

class Test3
{
	public static void main(String args[]) 
	{
		System.out.println("Hi");
		try{
			System.out.println(10/0);
		}
		catch(IOException e)
		{
			System.out.println("byee");	
		}
		catch(Exception e)
		{
			System.out.println("nooo");	
		}
		System.out.println("Hello");
	}
}
