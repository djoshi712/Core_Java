//ClassNotFoundException
class Ex3
{
	public static void main(String[] args) throws ClassNotFoundException
    {      
        Class.forName("Ex2");
    }
}

	