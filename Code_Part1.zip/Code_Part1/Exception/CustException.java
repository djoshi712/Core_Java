import java.util.Scanner;
class TooYoungException extends RuntimeException
{
	TooYoungException(String s)
	{
		super(s);
	}
}
class TooOldException extends RuntimeException
{
	TooOldException(String s)
	{
		super(s);
	}
}
class CustException
{
	public static void main(String args[]) 
	{	
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your age");
		int age=sc.nextInt();
		if(age>60)
		{
		throw new TooOldException("you have already crossed your age! No chance of getting married");
		}
		else if(age<18)
		{
		    throw new TooYoungException("wait for some time!!");
		}
		else 
		{
			System.out.println("welcome");
		}
	}
}
	