class MyOwnException
{
