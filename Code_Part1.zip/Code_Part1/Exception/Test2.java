

import java.io.*;
class Test2
{
	public static void main(String[] args) throws FileNotFoundException
	{		
			PrintWriter obj= new PrintWriter("D:/city.txt");
			System.out.println("Hi");
			System.out.println(10/0);
}}


