/*
import java.io.*;
class Checked2 {  
   public static void main(String args[]) throws FileNotFoundException, IOException
   {
	FileReader fr=null;
	try{
		fr= new FileReader("D:/newfile2.txt");
	}
	catch(FileNotFoundException e)
	{
		System.out.println("file does not exist");
	}
    int i=0;
	while ((i = fr.read()) != -1)
	{
		System.out.print((char)i);
	}
    }
}
*/
   


import java.io.*;
class Checked2 {  
   public static void main(String args[]) throws FileNotFoundException, IOException
   {
	   FileInputStream obj= null;
	  
	   try
	   {
		 obj = new FileInputStream("D:/C.txt"); 
	   }
	   catch (FileNotFoundException e)
	   {
		 System.out.println("file does not exist in remote location" );
		 try
		 {
		 	obj = new FileInputStream("D:/data.txt");
		 }
		 catch(FileNotFoundException f)
		 {
			 System.out.print("not available in local computer also");
			 System.out.println("Hi");
		 }
	   }
	   int k; 
	   obj = new FileInputStream("D:/data.txt"); 
	    while(( k = obj.read() ) != -1) 
			{ 
				System.out.print((char)k); 
			} 
			obj.close(); 
	}
   }


	