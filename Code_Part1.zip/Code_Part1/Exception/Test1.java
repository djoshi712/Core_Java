//checked exception> solution
import java.io.*;
class Test1
{
	public static void main(String[] args)
	{
		try
		{
		PrintWriter obj= new PrintWriter("");
		}
		catch(FileNotFoundException e)
		{
			System.out.println("trying to read from local computer");
		}	
		System.out.println("Hi");
}}
/*
import java.io.*;
class Test1
{
	public static void main(String[] args)throws FileNotFoundException
	{
			PrintWriter obj= new PrintWriter("");
			System.out.println("Hi");

}	}
/*

/*
constructor:
public PrintWriter(String fileName) throws FileNotFoundException

Class PrintWriter>>
	java.io.Writer
		java.io.PrintWriter
		
public class PrintWriter extends Writer
*/