import java.util.Scanner;

class TooYoungException extends Exception
{
	TooYoungException(String s)
	{
		super(s);
	}
}
class TooOldException extends Exception
{
	TooOldException(String s)
	{
	}
}


class Shaadi 
{
	public static void main(String args[]) throws TooOldException,TooYoungException
	{
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter your age");
		int age=sc.nextInt();
		if(age<18)
		{
			throw new TooYoungException("not eligible");
		}
		if(age>60)
		{
			throw new TooOldException("sorry!!");
		}
		else
		System.out.print("welcome");
}}