//default exception handler in java
class new1
{
	public static void main(String args[])
	{
		try{
	m1();}
	catch(ArithmeticException e)
	{
		System.out.println("infinite");
	}
	System.out.println("hello");
	}
	
	public static void m1() throws ArithmeticException
	{
	m2();
	System.out.println("hi");
	}
	
	public static void m2() throws ArithmeticException
	{
		System.out.println("Testing");
		System.out.println(10/0);
		System.out.println("Hi from first");
	}
}	

