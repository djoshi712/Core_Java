//throws basics 
class Test7
{
	public static void main(String args[]) 
	{
		doStuff();
		
	}
	public static void doStuff() 
	{	try{	
	doMoreStuff();} catch(InterruptedException e){  }	
	}
	public static void doMoreStuff() throws InterruptedException
	{
		System.out.println("hello before sleeping");
		Thread.sleep(10000);
		System.out.println("Hello after sleeping");
	}
}