//methods to print exception information
//methods

class Test5 extends Object
{
	public static void main(String args[])
	{
		try
		{
			System.out.println(10/0);  				//risky code
		}
		catch(ArithmeticException e)
		{
		e.printStackTrace();		
		System.out.println(e.toString()); 	
		System.out.println(e.getMessage());		
		}
		System.out.println("\nHello"); 
	}
}

/*
printStackTrace:
java.lang.Object
java.lang.Throwable

getMessage:
java.lang.Object
java.lang.Throwable
*/