import java.util.Scanner;
class TooYoungException extends Exception
{
	TooYoungException(String s)
	{
		super(s);
	}
}

class TooOldException extends Exception
{
	TooOldException(String s)
	{
		super(s);
	}	
}

class Age 
{
	public static void main(String args[]) throws TooOldException, TooYoungException
	{
		Scanner sc= new Scanner(System.in);
		System.out.print("Enter your age");
		int a= sc.nextInt();
		if(a<18)
		{
			throw new TooYoungException("not eligible");
		}
		if(a>70)
		{
			throw new TooOldException("too late");
		}
		else
			System.out.print("welcome");
			
		
	}
}	
		
