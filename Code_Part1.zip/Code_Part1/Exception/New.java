class New extends RuntimeException
{
	
}