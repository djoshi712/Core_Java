
class Test4
{
	public static void main(String args[]) throws ArithmeticException
	{		
		System.out.println(10/0);		
	}
}
