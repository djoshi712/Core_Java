//checked exception> error
import java.io.*;
class Test8
{
	public static void main(String[] args) throws FileNotFoundException
	{
			PrintWriter obj= new PrintWriter("");
			System.out.println("Hi");
}	}
