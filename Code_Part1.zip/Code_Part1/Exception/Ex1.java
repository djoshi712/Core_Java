import java.io.*;
import java.util.List;
import java.util.ArrayList;

class ListOfNumbers {

    private List<Integer> list;
    private static final int SIZE = 10;

    public ListOfNumbers () {
        list = new ArrayList<Integer>(SIZE);
        for (int i = 0; i < SIZE; i++) {
            list.add(i);
        }
    }

    public void writeList() throws IOException
     {
      try
      {
        PrintWriter out = new PrintWriter(new FileWriter("OutFile.txt"));
        for (int i = 0; i < SIZE; i++) 
          {
              out.println("Value at: " + i + " = " + list.get(i));
          }
      }
      catch (IndexOutOfBoundsException e) 
      {
        System.err.println("IndexOutOfBoundsException: " + e.getMessage());
      } 
      catch (IOException e) 
      {
        System.err.println("Caught IOException: " + e.getMessage());
      }
    }
    //what if this is unreachable??
    
    out.close();
    
}

class Main
{
  public static void main(String[] args) throws IOException
  {
    new ListOfNumbers().writeList();
  }
}