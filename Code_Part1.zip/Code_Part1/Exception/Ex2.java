
class Example
{  
  public static void main(String args[]){ 
    try{   
  m1();}
  catch(ArithmeticException e)
  {
    System.out.println("diving number by zero");
  }
  System.out.println("hello");
}  

public static void m1()
{
	m2();
  System.out.println("hi");
  System.out.println("hi");
}

public static void m2()
{
	System.out.println(10/0);
  System.out.println("bye");
  System.out.println("bye");
}
}




