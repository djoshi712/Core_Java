/*Null Pointer Exception
*Thrown when an application attempts to use null in a case 
where an object is required. These include:

1.Calling the instance method of a null object.
2.Accessing or modifying the field of a null object.
3.Taking the length of null as if it were an array.
4.Accessing or modifying the slots of null as if it were an array.
5.Throwing null as if it were a Throwable value.
Applications should throw instances of this class to indicate 
other illegal uses of the null object.
*/
class Try
{
 static String a;
 public static void main(String[] args)
 {
 int b=a.length();
 System.out.println(b);
 }
}
 