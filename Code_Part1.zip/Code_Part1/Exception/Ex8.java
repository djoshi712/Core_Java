
class Ex8
{
	
 public static void main(String[] args) {
        
            String s = "hello";
            int i = Integer.parseInt(s);			      		
}
}

