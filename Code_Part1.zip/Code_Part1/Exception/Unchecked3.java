
class Unchecked3 
{  
   public static void main(String args[])
   {
	try
	{
		int arr[] ={1,2,3,4,5};
		System.out.println(10/0);
		System.out.println(arr[7]);	
	}
	catch(ArithmeticException e)
	{
		System.out.println("this is divide by zero exception");
    }	
	catch(Exception e)
	{
		System.out.println("The specified index does not exist in array. Please correct the error");
	}
System.out.println("hi");
}
}