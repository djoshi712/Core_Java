class Emp
{
	int id;
	String name;
	Emp(int id, String name)
	{
		this.id=id;
		this.name=name;
	}
}
class Student
{
	int id;
	String name;
	Student(int id, String name)
	{
		this.id=id;
		this.name=name;
	}
}	
class Array
{	
	public static void main(String []args)
	{
	Object[] o= new Object[8];
	o[0]= new Emp(1, "Anjali");
	o[1]= new Emp(2, "Rahul");
	o[2]= new Emp(3, "Prateek");
	o[3]= new Student(1, "Anjali");
	o[4]= new Student(2, "Rahul");
	o[5]= new Student(3, "Prateek");
	o[6]=new Integer(10);
	/*for(Emp ee: e)
	{
	System.out.println(ee.id+"---"+ee.name);
	}
	}*/
	for(Object oo: o)
	{
		System.out.println(oo.id+"---"+oo.name);
		if(oo instanceof Emp)
		{
			Emp ee=(Emp)oo;
			System.out.println(ee.id+"---"+ee.name);
		}
		if(oo instanceof Student)
		{
			Student s= (Student)oo;
			System.out.println(s.id+ "----" +s.name);
		}
		if(oo instanceof Integer)
		{
			System.out.println(oo);
		}
	}	
}
}
