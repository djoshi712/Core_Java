
/* 1.Data type represents type of the variable
2.Data type decides memory size of the variable
Exampel: for integer 4 bytes of memory is allocated, float 4 bytes, char 2 bytes
3. Range of the variable is decided by datatypes
Example: byte (-128 to 127)
4. Java contains eight primitive data types: byte, short, int, long to represent the numeric value
float and double to represent the decimal value
char to represent the char value
boolean to represent true and false
5. size and data types

*/

class Test1 
{
	
	int eid=112;		
/*	int		......> data type, 
	eid		......> variable name, 
	==		......> assignment operator, 
	112		......> constant value or literal
	;		......>	statement terminator

	if we dont assign any value, JVM assigns default values
	
public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
