//anon class that extends Thread class
/*
class Lays
{
	public void taste()
	{
		System.out.println("salty");
	}
	//100 more methods
}
//Annoymous class extending Lays class

class Test
{	
	public static void main(String[] args)
	{
		Lays l1= new Lays()
		{
			public void taste()
			{
				System.out.println("spicy");
			}
		};
	
	
		Lays l2= new Lays()
		{
			public void taste()
			{
				System.out.println("sweet");
			}
		};

	l1.taste();
	l2.taste();
	Lays l= new Lays();
	l.taste();
	}
}
*/
//Thread class example

class MyThread extends Thread{
	public void run()
	{
		for(int i=0; i<5; i++)
		{
			System.out.println("Hi from child thread");
		}
	}
}
class Test{
	public static void main(String[] args)
	{

		Thread t = new Thread()
		{
			public void run()
			{
				for(int i=0; i<5; i++)
				{
					System.out.println("Hi from child thread");
				}
			}
		};
		t.start();
		for(int i=0; i<5; i++)
		{
			System.out.println("Hi from main thread");
		}
	}
}







		Thread t= new MyThread();
		t.start();
		
	}
}


class Test{
	public static void main(String[] args)
	{
		Thread t= new MyThread();
		t.start();
		for(int i=0; i<5; i++)
		{
			System.out.println("Hi from main thread");
		}
	}
}
/*
//creating Annoymous class extending Thread class
class Test{
	public static void main(String[] args)
	{
		Thread t= new Thread()
		{
			public void run()
			{
				for(int i=0; i<5; i++)
				{
					System.out.println("Hi from child thread");
				}
			}
		};
		t.start();
		for(int i=0; i<5; i++)
		{
			System.out.println("Hi from main thread");
		}
	}
}
*/

