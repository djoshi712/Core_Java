//https://www.geeksforgeeks.org/difference-between-aggregation-and-composition-in-java/
//http://java.scjp.jobs4times.com/inner.htm
//https://www.geeksforgeeks.org/what-is-has-a-relation-in-java/#:~:text=In%20Java%2C%20a%20Has%2DA%20relationship%20essentially%20implies%20that%20an,executes%20a%20Has%2DA%20relationship.
//https://stackoverflow.com/questions/5529454/does-an-inner-class-work-as-a-composition-relationship-in-java

/*  class Outer1
{
	int a=10;
	static int y=20;
	class Inner
	{
		void m1()
		{
			System.out.println(a);
			System.out.println(y);
		}
	}
	public static void main(String[] args)
	{
		new Outer1().new Inner().m1();
	}
}  */
/*
 class Outer1
{
	int a=10;
	class Inner
	{
		int a=30;
		void m1()
		{
			int a=40;
			System.out.println(a);
			System.out.println(this.a); //current inner class object
			//System.out.println(Inner.this.a);
			System.out.println(Outer1.this.a); //current outer class object			
		}
	}
	public static void main(String[] args)
	{
		new Outer1().new Inner().m1();
	}
} 
*/

//modifiers applicable for inner classes: private, protected and static + outer class modifiers
//public, default, final, abstract, strictfp>> outer class
/*  class A
{
	class B
	{
		class C
		{
			void m1()
			{
			System.out.println("hiiiii");
			}
	}	}
	
}
class Main
{
	public static void main(String[] args)
	{
		A a= new A();
		A.B b= a.new B();
		A.B.C c= b.new C();
		c.m1();
		//new A().new B().new C().m1();
	}
} */