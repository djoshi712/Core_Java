//ann inner that define inside method arguments
//creating a thread using ann inner class by implementing Runnable interface
/*
/*
class MyThread implements Runnable{
	public void run()
	{
		for(int i=0; i<5; i++)
		{
			System.out.println("Hi from child thread");
		}
	}
}
class Test{
	public static void main(String[] args)
	{
		Runnable r= new MyThread();
		Thread t= new Thread(r);
		t.start();
		for(int i=0; i<5; i++)
		{
			System.out.println("Hi from main thread");
		}
	}
}
*/
/*
class Test{
	public static void main(String[] args)
	{
		Runnable r= new Runnable()
		{
			public void run()
			{
				for(int i=0; i<5; i++)
				{
					System.out.println("Hi from child thread");
				}
			}
		};
		Thread t= new Thread(r);
		t.start();
		for(int i=0; i<5; i++)
		{
			System.out.println("Hi from main thread");
		}
	}
}
*/




/*
class Test{
	public static void main(String[] args)
	{
		Runnable r= new Runnable()
		{
			public void run()
			{
				for(int i=0; i<5; i++)
				{
					System.out.println("Hi from child thread");
				}
			}
		};
		Thread t= new Thread(r);
		t.start();
		for(int i=0; i<5; i++)
		{
			System.out.println("Hi from main thread");
		}		
	}
}
*/

//creating a thread using ann inner class created inside method arguments

class Test{
	public static void main(String[] args)
	{
        Thread t= new Thread(new Runnable()
        {
            public void run()
			{
				for(int i=0; i<5; i++)
				{
					System.out.println("Hi from child thread");
				}
			}
        });
		t.start();
        for(int i=0; i<5; i++)
		{
			System.out.println("Hi from main thread");
		}
    }

}
