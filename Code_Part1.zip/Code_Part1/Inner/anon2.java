//anon class that implements an interface


interface Lays
{
	public void taste();

}

//Annoymous class implementing Lays interface
 class Test
{		
	public static void main(String[] args)
	{
		Lays l1= new Lays()
		{
			public void taste()
			{
				System.out.println("spicy");
			}
		};

		Lays l2= new Lays()
		{
			public void taste()
			{
				System.out.println("sweet");
			}
		};

	l1.taste();
	l2.taste();
	// System.out.println(l1.getClass().getName()); 
	// System.out.println(l2.getClass().getName());
	}
}  

//creating a thread by implementing Runnable interface

class MyThread implements Runnable{
	public void run()
	{
		for(int i=0; i<5; i++)
		{
			System.out.println("Hi from child thread");
		}
	}
}
class Test{
	public static void main(String[] args)
	{
		Runnable r= new MyThread();
		Thread t= new Thread(r);
		t.start();
		for(int i=0; i<5; i++)
		{
			System.out.println("Hi from main thread");
		}
	}
}



class Test{
	public static void main(String[] args)
	{
		Runnable r = new Runnable()
		{
			public void run()
			{
				for(int i=0; i<5; i++)
				{
					System.out.println("Hi from child thread");
				}
			}
		};
		Thread t= new Thread(r);
		t.start();
		for(int i=0; i<5; i++)
		{
			System.out.println("Hi from main thread");
		}
	}
}





		
	}
}



*/
//creating a thread by implementing Runnable interface using anonymous inner class
/*
class Test{
	public static void main(String[] args)
	{
		Runnable r= new Runnable()
		{
			public void run()
			{
				for(int i=0; i<5; i++)
				{
					System.out.println("Hi from child thread");
				}
			}
		};
		Thread t= new Thread(r);
		t.start();
		for(int i=0; i<5; i++)
		{
			System.out.println("Hi from main thread");
		}
	}
}
*/
/*interface Lays
{
	public void taste();

} */
/* 
//Anonymous Inner class that defines inside method/constructor argument :
 class Test
{		
	public static void main(String[] args)
	{
		Lays l= new Lays()
		{
			public void taste()
			{
				System.out.println("spicy");
			}
		};
	
	l.taste();
	//Lays l1= new Lays();
	//l1.taste();
	Lays l2= new Lays()
		{
			public void taste()
			{
				System.out.println("sweet");
			}
		};
	l2.taste();
	System.out.println(l.getClass().getName()); 
	//System.out.println(l1.getClass().getName());
	System.out.println(l2.getClass().getName());
	}
}   */

 