//method local inner class
 class Test4
{
	int x;
	int  y;
	public static void m1()
	{
		class Inner
		{
			void sum(int a, int b)
			{
				System.out.println(x);
				System.out.println(y);
				System.out.println(a+b);
			}
		}
	Inner i=new Inner();	
	i.sum(10,20);
	
	
	i.sum(20,40);
	
	}
	public static void main(String[] args)
	{
		new Test4().m1();
	}
	
} 
		
/* class Test4
{
	int x=10;
	static int y=20;
	public void m1()		//make it static and check
	{
		class Inner
		{
			public void m2()
			{
				System.out.println(x);
				System.out.println(y);
			}
		}
		new Inner().m2();
	}
	
	public static void main(String[] args)
	{
		new Test4().m1();
	}
}  */

/* class Test4
{
	int x=10;
	private int y=20;
	public void m1()		//make it static and check
	{
		int a=100;
		class Inner 				//only applicable modifier for method local inner classes are final, abstact and strictfp
		{ 
			public void m2()
			{
				int z=200;
				System.out.println(a);
				System.out.println(x);
				System.out.println(y);
				System.out.println(z);
			}
		}
		new Inner().m2();
	}	
	public static void main(String[] args)
	{
		new Test4().m1();
	}
}  */ 
/* 
class Test4
{
	int a=10;
	static int y=20;
	public void m1()		
	{
		int a=100;
		class Inner 		
		{ 
			public void m2()
			{
				int a=200;
				System.out.println(a);
				System.out.println(this.a);
				System.out.println(y);
				System.out.println(z);
			}
		}
		new Inner().m2();
	}	
	public static void main(String[] args)
	{
		new Test4().m1();
	}
}  */



