/*  //normal inner class
 class Outer
{
	class Inner
	{
		public static void main(String[] args)
		{
			System.out.println("inner");
		}	 
					
	}	
	 

}  */  


/* class Uni
{
	class Dept
	{
		String getDeptHod()
		{
			return "Dr. Neelu Jyoti";
		}	
	}
	public static void main(String[] args)
	{
		Uni u= new Uni();
		Uni.Dept i= u.new Dept();
		System.out.println(i.getDeptHod());
		//new Uni().new Dept().getDeptHod();
			
	}
	
}   */
  

//Access inner class member from instance area of Outer class 
/*   class Outer
{
	class Inner
	{
		public void m1()
		{
			System.out.println("inner");
		}
	}	
	void m2()
	{
		Inner i= new Inner();
		i.m1();
		
	}		
	public static void main(String[] args)
	{
		Outer o= new Outer();
			o.m2();
	}
		
}   */

//Access inner class member from Outer class
/*  class Outer
{
	class Inner
	{
		public void m1()
		{
			System.out.println("inner");
		}
	}

}


class Test
{		
public static void main(String[] args)
		{
		new Outer().new Inner().m1();
		}
		
	
}  */  

