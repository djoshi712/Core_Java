//static nested class

class Test5
{
	 int x=10;
	static class Inner
	{
		public void m1()
		{
			System.out.println("static nested class method");
			System.out.println(x);
		}
	}
	public static void main(String[] args)
	{
		new Inner().m1();
	}
}
	
/*class Test5
{
	static class Inner
	{
		public static void main(String[] args)
		{
			System.out.println("static nested class main method");
		}
		public void m1()
		{
			System.out.println("static nested class method");
		}
	}
	public static void main(String[] args)
	{
		System.out.println("outer class main method");
	}
}*/
	