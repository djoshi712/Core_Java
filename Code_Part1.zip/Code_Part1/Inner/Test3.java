//method-local inner class

/*class Test3
{
	public void m1()
	{
		public void sum(int x, int y)
		{
			System.out.println("sum is:" +(x+y));
		}
		;
		;
		;
		sum(10,20);
		;
		;
		sum(100,200);
		;
		;
	}
}*/


//using method-local inner classes

 class Test3
{
	
	public  void m1()
	{	
		class Inner
		{
			public void sum(int x, int y)
			{
			System.out.println("sum is:" +(x+y));
			}
		}
		Inner i= new Inner();
		i.sum(10,20);
		;
		;
		i.sum(100,200);
		
	}
	public static void main(String[] args)
	{
		new Test3().m1();
	}
} 
	

	
			
		
	
