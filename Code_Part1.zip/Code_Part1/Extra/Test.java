//output?
class Test{
    static int a;     
    static   {
        a = 4;
        System.out.println ("inside static block\n");
        System.out.println ("a = " + a);  }     
    Test()   {
        System.out.println ("\ninside constructor\n");
        a = 10;    }
    public static void func()  {
        a = a + 1;
        System.out.println ("a = " + a);  }     
    public static void main(String[] args) { 
        Test obj = new Test();
        obj.func();   }}

// output?
class Test {
  int i;
} 
class Main {
   public static void main(String args[]) { 
     Test t; 
     System.out.println(t.i); 
   }
//output
 class Test {
  int i;
} 
class Main {
  public static void main(String args[]) { 
      Test t = new Test(); 
      System.out.println(t.i);
   } 
}
//output
class demo
{
    int a, b;
     
    demo()
    {
        a = 10;
        b = 20;
    }
     
    public void print()
    {
        System.out.println ("a = " + a + " b = " + b + "\n");
    }
}
 
class Test
{
 
    public static void main(String[] args)
    {
        demo obj1 = new demo();
        demo obj2 = obj1;
 
        obj1.a += 1;
        obj1.b += 1;
 
        System.out.println ("values of obj1 : ");
        obj1.print();
        System.out.println ("values of obj2 : ");
        obj2.print();
 
    }
}
//output
class demoClass
{
    int a = 1;
 
    void func()
    {
        demo obj = new demo();
        obj.display();
    }
 
 
    class demo
    {
        int b = 2;
 
        void display()
        {
            System.out.println("\na = " + a);
        }
    }
 
    void get()
    {
        System.out.println("\nb = " + b);
    }
}
 
 
class Test
{
    public static void main(String[] args)
    {
        demoClass obj = new demoClass();
        obj.func();
        obj.get();
 
    }
}