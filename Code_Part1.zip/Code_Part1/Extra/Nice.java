class Nice 
{
	int a=20;
	static{
		int a=10;
		Nice obj=new Nice();
		System.out.println(a);	}
	{
		System.out.println(a);
	}
	Nice(){	System.out.println("inside cons");}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
