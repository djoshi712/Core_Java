class DefaultCons 
{
	 int a;

	{
		a=10;
	}

	public static void main(String[] args) 
	{
	
		DefaultCons obj= new DefaultCons();
		System.out.println("Hello World!");
	}
}
