// Java code for using 'this' 
// keyword as method parameter
class This
{
    int a;
    int b;
    Test()
    {
        a = 10;
        b = 20;
    }
     //Method that receives 'this' keyword as parameter
    void display(This obj)
    {
        System.out.println("a = " + a + "  b = " + b);
    }
    void get()
    {
        display(this);
    } 
    public static void main(String[] args)
    {
         new This().get();
    }
}