//which will load first static variable or static block?
//Static variable or method is executed sequentially, in the order in which it is defined in the class
class A {
public static void main(String args[])
{
    System.out.print(A.x);
}

static {
    System.out.print(A.x);
}


static int x=10;
}

//0 10

class A {
static int x=10;
public static void main(String args[])
{
    System.out.print(A.x);
}
static {
    System.out.print(A.x);
}
}

// 10 10