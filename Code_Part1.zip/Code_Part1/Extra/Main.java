//output?
class C {
  int a = 20;
  C() {
    a = 40;
  }
}
class Main {
   public static void main(String args[]) {
      C obj = new C();
      System.out.println(obj.a);
   }
}

