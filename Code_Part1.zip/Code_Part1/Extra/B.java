//this pointer

class B {	
    B example() {
	System.out.println(this);
    return this;
    }
public static void main(String [] args)	{
	B obj= new B().example();
	System.out.println(obj);
}
}

//Output:  B@15db9742
B@15db9742