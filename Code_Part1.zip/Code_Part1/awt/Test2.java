/*Task: 
Component: TextField, TextArea, Button
Container(group of components): Frame,  
Event: java.awt.event.*; Dynamic 
*/

import java.awt.*;
import java.awt.event.*;

class Test2
{
	public static void main(String[] args)
	{
	Frame f= new Frame();
	f.setVisible(true);
	f.setBackground(Color.darkGray.darker());
	f.setSize(500,500);
	f.setTitle("Login Page");
	
	Label l1= new Label("username: ");
	Label l2= new Label("password: ");
	
	TextField t1= new TextField(30);
	TextField t2= new TextField(30);
	
	Button b= new Button("Login");
	//bydefault: components are not added into the frame
	f.add(l1); 
	f.add(t1);
	f.add(l2); 
	f.add(t2);
	f.add(b); 
	//only button displayed because, we are adding the data into the frame, entire frame is occupied with username

	}
}