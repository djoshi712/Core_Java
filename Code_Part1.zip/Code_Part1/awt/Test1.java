//Task: Creation of Frame Object

//1995: develop java application using awt(used to prepare GUI Components)
//java.awt ---package(classes and packages)
//component--- object(label, textfield, button etc.)
//frame is a container (group of container)
//By using awt we prepare components, by default: static>>no life i:e by clicking login button, no event occurs
//To provide dynamic nature(life to the component) we use interfaces present in java.awt.event package. 
//event:action performed on component/object to provide the dynamic nature.
//awt components are heavy weight and platform independent
//Object class> Component> {TextComponent(TextField,TextArea), Button, CheckBox, Canvas, Windows(Panel), container(Frame}
//Frame: basic component in awt(displays all the component of awt)
//create a frame: extend Frame class or create frame object
//ctrl+c >> close the file

//1. creaing frame object

import java.awt.*;		//static component
/*
class Test1
{
	public static void main(String[] args)
	{
	Frame f= new Frame(); //invisible mode
	f.setVisible(true); //0 pix height and 0 pix width
	f.setSize(500,500);
	f.setBackground(Color.pink.darker()); 
	f.setTitle("hi");
	}
}
*/
//2. creating frame object
class Myframe extends Frame
{
	Myframe()
	{
	this.setVisible(true);
	//setVisible(true);
	setSize(500,500);
	setBackground(Color.green.darker());
	}	
	Myframe f= new Myframe();
}