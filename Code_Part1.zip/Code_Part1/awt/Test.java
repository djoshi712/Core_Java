import java.awt.*;
import java.awt.event.*;
class Test
{
	public static void main(String[] args)
	{
		Frame f= new Frame();
		f.setSize(1000,500);
		f.setVisible(true);
		f.add(new Label("Hi!!! Learning anonymous inner classes"));
		f.addWindowListener(new WindowAdapter() 	//The object can be registered using the addWindowListener() method.
	                                                //java.awt.event.WindowAdapter class
		{							
			public void windowClosing(WindowEvent e)
			{	 
				for(int i=1;i<=10;i++)
				{
					System.out.println("I am closing window" +i);
				}
				System.exit(0);
			}
		});
	}
}