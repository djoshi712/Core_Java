class A 
{
public void m1(){
	System.out.println("m1 method");}
void m2(){
	System.out.println("m2 method");}
}
class B extends A
{
void m3(){
	System.out.println("m3 method");}
void m4(){
	System.out.println("m4 method");}
} 
class C extends B
{	
	void  m5(){System.out.println("m5 method");}
	void  m6(){System.out.println("m6 method");}		
	public static void main(String[] args) {	
	A obj=new A();
	obj.m1(); obj.m2();
	obj.getclass();
	B obj1= new B();
	obj1.m1(); obj1.m2(); obj1.m3(); obj1.m4();

	C obj2= new C();	
	obj2.m1();obj2.m2(); obj2.m3(); obj2.m4(); obj2.m5(); obj2.m6();
	
}}
