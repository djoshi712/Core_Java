
/* Types of inheritance:
1. single: 
2. Multilevel: 
3. Hierarchical
4. Multiple:
5. Hybrid: Multiple+ Hierarchical
 */
 // Case-1
class A
{
}
class B extends A
{
}
class C extends A
{
}
// Case-2
class A
{
}
class B extends A
{
}
class C extends A, B
{
}

