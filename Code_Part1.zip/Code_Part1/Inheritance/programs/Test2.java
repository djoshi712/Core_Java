using Inheritance to reduce redundancy of the application and length of the code
>it is possible to create objects of both the classes
>the class providing properties: parent class/super/base class
> 



class A{
	void m1(){}			//total methods: 2
	void m2(){}}  

class B extends	A{		//code reusability is done using extends keyword, total 4 methods are present
	void m3(){}			//total methods: 4
	void m4(){}}

class C extends B{		//purpose of extends keyword: provides relationship between 2 classes 
	void m5(){}			//total methods: 6
	void m6(){}}  

/modification-1
class A
{
	void m1(){}		
	void m2(){}
}  
class B extends	A		
{
	void m3(){}			//contains 4 methods
	void m4(){}
}
class C extends A	   //contains 4 methods
{
	void m5(){}			
	void m6(){}
}  	
// Modification-2
class A
{
	void m1(){}			//contains 2 methods
	void m2(){}
}  

class B extends	C		
{
	void m3(){}			//contains 6 methods
	void m4(){}
}

class C extends A	   //contains 4 methods
{
	void m5(){}			
	void m6(){}
}  

// Modification-3
class A
{
	void m1(){}			//contains 2 methods
	void m2(){}
}  
class B 		
{
	void m3(){}			//contains 2 methods
	void m4(){}
}
class C extends A,B									//you might think that this class contains 6 methods, But here class C doesnot contains 6 methods
													//This is called multiple inheritance and is not allowed in java
{
	void m5(){}			
	void m6(){}
}  

// Modification-4
class A					//parent is providing the properties called super class
{
	void m1(){}			//contains 2 methods
	void m2(){}
}  

class B extends	A		//acquiring the property from super class called child/derived class
{
	void m3(){}			//contains 6 methods
	void m4(){}
}

class C extends	B		
{
	void m3(){}			//contains 6 methods
	void m4(){}
}