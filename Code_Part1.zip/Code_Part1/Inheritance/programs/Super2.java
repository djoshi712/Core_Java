//Second use of super
class A
{
	int a;	
}
class B extends A
{
	int a;									//this a hides the a in A class
	B(int x, int y)
		{
			a=x;
			super.a=y;
		}
	void display()
	{
		System.out.println(super.a);
		System.out.println(a);
	}
}
 class Super2
 {
	 public static void main(String[] args) 
	{
		B obj=new B(10,20);
		obj.display();

	}
 }