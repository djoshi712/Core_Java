//A superclass variable can reference a subclass object
/*
class Test 
{
	int i=10;	
}
class Test1 extends Test
{
	int j=20;	
}
class Refer
{
	public static void main(String[] args) 
	{		Test o= new Test(); //superclass
		    Test1 o1= new Test1(); //subclass
			o=o1;
			// or Test obj=new Test1();
			System.out.println(o1.i);
			System.out.println(o1.j);
			System.out.println(o.i);
		
	}

}
*/
class Test 
{
	int i=10;	
}
class Test1 extends Test
{
	int i=20;	
	
}
class Refer
{
	public static void main(String[] args) 
	{		
		    Test1 o1= new Test1(); //subclass
		
		
	}

}
