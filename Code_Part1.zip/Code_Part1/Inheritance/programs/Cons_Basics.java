 class  A extends Object
{
	A(){
			super(); //
		System.out.println("A class cons");}
}
class B extends A
{
	B(){	
		super();
		System.out.println("B class cons");}
}
class C extends B
{
	C(){
		super();
		System.out.println("C class cons");}
}
class Main
{
	public static void main(String[] args) 
	{
		C obj=new C();
	}
} 
