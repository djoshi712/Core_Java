//using final to prevent inheritance in java
 class A 
{
}
final class Test6 extends A
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
/*
class A 
{
}
final class Test6 extends A
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
*/
