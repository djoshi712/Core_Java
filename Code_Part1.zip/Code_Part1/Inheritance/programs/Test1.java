/* OOPS: Inheritance, Polymorphism, abstraction, encapsulation, classes and objects
> class is a blueprint, it decides object creation, without class there is no object.
> Based on the single blueprint, we can create many objects(physical entity) but every object occupies memory.
>Inheritance: Process of acquring properties from one class to another is called inheritance.
Inheritance: Father-child Relationship
> Reduce the length of the code and reduce the redundancy of the application.
> Reduce redundancy by not declaring the methods already defined in the above classes but instead reuse the methods.
How to do that? 
> There has to be a relation between two classes. Use extends keyword. once we extends the class, automatically code is reused.
*/
// Application without inheritance:

class A{
	void m1(){}			//contains m1 and m2 methods
	void m2(){}}
class B{
	void m1(){}			//also require m1 and m2 methods
	void m2(){}
	void m3(){}
	void m4(){}}
class C{
	void m1(){}			//m1, m2, m3, m4 are already defined, duplication of code is the biggest disadvantage here, Also, lenght of the code is increasing				
	void m2(){}	
	void m3(){}
	void m4(){}
	void m5(){}
	void m6(){}}	
public static void main(String[] args) {
		System.out.println("Hello World!");}
}
