public class Solution {

    public static void main(String[] args) {
        int x=0;
        for(int j=0,k=0;j<n && k<=n-1;j++,k++){
            x=(int)Math.pow(2,k)*b + x;
             System.out.print(a+x+" ");
    }
}