 /* Difference between java and C++ (Inheritance)

 a. In Java, all classes inherit from the Object class directly or indirectly. 
 Therefore, there is always a single inheritance tree of classes in Java, 
 and Object class is root of the tree. In Java, if we create a class 
 that doesn�t inherit from any class then it automatically inherits from 
 Object class.
>instanceof(): used only for object reference variables
>the opertor checks whether the object is of a particular (class type or 
interface type)
>syntax:  (object refernce variable) instance of (class/ interface type)

b. In Java, members of the grandparent class are not directly accessible.

*/
//code supporting point a
/*

class Test { 
    // members of test
}
class Difference {
  public static void main(String[] args) {
    Difference t = new Difference();    
    System.out.println("t is instanceof Object: " + (t instanceof Object));
  }
}
*/

class A
{
	public static void main(String[] args) {
    String a= "Dhoni"  ;
    System.out.println((a instanceof Object));
  }

}


//code suporting point b

//There is error in line �super.super.print();�. In Java, a class cannot 
//directly access the grandparent�s members. It is allowed in C++ though. 
//In C++, we can use scope resolution operator (::) to access any ancestor�s
//member in inheritance hierarchy. In Java, we can access grandparent�s 
//members only through the parent class.

// Incorrect code:
/*
class Grandparent {
    public void Print() {
        System.out.println("Grandparent's Print()");
    }
}
  
class Parent extends Grandparent {
    public void Print() {       
        System.out.println("Parent's Print()");
    }
}
  
class Child extends Parent {
    public void Print() {
        super.super.Print();  // Trying to access Grandparent's Print()
        System.out.println("Child's Print()");
    }
}
  
public class Difference {
    public static void main(String[] args) {
        Child c = new Child();
        c.Print();
    }
}
*/

// correct version of the above code
/*
class Grandparent {
    public void Print() {
        System.out.println("Grandparent's Print()");
    }
}
  
class Parent extends Grandparent {
    public void Print() {
        super.Print();
        System.out.println("Parent's Print()");
    }
}
  
class Child extends Parent {
    public void Print() {
        super.Print();
        System.out.println("Child's Print()");
    }
}
  
public class Difference {
    public static void main(String[] args) {
        Child c = new Child();
        c.Print();
    }
}
*/