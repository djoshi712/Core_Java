//1. use super 	keyword to call the constructor of super class.
/*
class ParentCons 
{
 	ParentCons()
	{
	 System.out.println("super class cons");
	 }
}
class ChildCons extends ParentCons
{
	ChildCons()
	{	
		this(10.5f);		
		System.out.println("child class 0 arg cons");
	}
	ChildCons(float a){
		//super();
		System.out.println("child class 1 arg cons");}
	public static void main(String[] args)
	{
		new ChildCons();
	}
} */ 

/*  class ParentCons 
{
 ParentCons(){System.out.println("super class cons");}
}
class ChildCons extends ParentCons
{
	ChildCons(){
		this(10.5f);
		System.out.println("child class 1 arg cons");}
	ChildCons(float a){	
		System.out.println("parent class 0 arg cons");
		super();}		
	public static void main(String[] args){
	new ChildCons();}
} */
 
//3.super must be the first statment
/*   class ParentCons 
{
 ParentCons(){System.out.println("super class cons");}
}
class ChildCons extends ParentCons
{
	ChildCons(){		
		 
		super();		
		this(10.5f);
		System.out.println("child class 1 arg cons");}

	ChildCons(float a){		
		System.out.println("parent class 0 arg cons");}
	
	public static void main(String[] args){
	new ChildCons();}
}  
 */

//4.Important: Every class has a default constructor 
//and it calls a default constructor of parent class 
//(if it has a parent class) otherwise it calls the
// parent class of all the classes "Object" class(primordial).
//default constructor calls the default constructor
//(0-agr constructor) of its immediate super class
//If the class being declared is the primordial class 
//Object, then the default constructor has an empty body. 
//Otherwise, the default constructor simply invokes the 
//immediate superclass constructor with no arguments.


class ParentCons extends Object
{
	ParentCons()
	{
		System.out.println("A");
	}
}
class ChildCons extends ParentCons
{
	ChildCons()
	{
	System.out.println("B"); 
	}
	public static void main(String[] args){
	new ChildCons();
}
}  
/*   class ParentCons 
{
	ParentCons()
	{
		System.out.println("parent class 0 arg cons");
	}
}
class ChildCons extends ParentCons
{
	public static void main(String[] args)
	{
	new ChildCons();
	}
} */  



//5. Important: compiler genreates super keyword at first line of the constrcutor if no super or this keyword is used.  
 /* class ParentCons 
{
	ParentCons(){System.out.println("parent class 0 arg cons");}
}

class ChildCons extends ParentCons
{
	ChildCons(double b)
	{
		System.out.println("child class 0 arg cons");
	}			
	public static void main(String[] args){
	new ChildCons(20.9);}
}
 */ 

  /*class ParentCons 
{
	ParentCons(int a)
	{
		System.out.println("parent class 0 arg cons");
	}
}
class ChildCons extends ParentCons
{
	ChildCons()
	{
		System.out.println("child class 0 arg cons");
	}			
	public static void main(String[] args)
	{
	new ChildCons();
	}
}  */

/*  class ParentCons 
{
	ParentCons(){System.out.println("Parent class 0 arg cons");}
} 
 class ChildCons extends ParentCons
{
	ChildCons()
	{
		System.out.println("child class 0 arg cons");
	}
	ChildCons(int a)
	{
		System.out.println("child class 1 arg cons");
	}
	public static void main(String[] args){
	new ChildCons();
	new ChildCons(10);}
}  */
