	class Animal 
	{    
	   public void move()
	   {
		  System.out.println("Animals can move");
	   } 	
	}
	class Dog extends Animal 
	{
	   public void move()
	   {
		  System.out.println("Dogs can walk and run");
	   }
	    public void m1()
	   {
		   System.out.println("HI");
	   }
	}
	 class TestDog 
	 {

	   public static void main(String args[]) 
	   {
		//   Animal a = new Animal(); 
		//   a.move();
		  Animal b = new Dog(); 
		  b.m1();
	   }
	}