//method overriding:
//to achieve overriding atleast two classes are required with inheritance
//relationship.
//Declaring a method in subclass which already present in parent class is 
//known as method overloading.
//Rules to follow: 
//1.Parent class and child class method signature must be same.
//2.The return type must be same for primitive types(byte, short, int, 
//long, float, double, char, boolean) for super and subclass.
//3.Covariant return types(introduced in 1.5 version):Changing the return 
//type is possible for class types.
//4. Child class method cannot override final methods in parent class. 
//5. Method hiding: It is not possible to override static methods because
//static methods are bond to class.
//6.Private modifier: applicable for methods and varibles. Most restricted modifier

//Overriding simple example:
  /* class Animal
{
	 void move(){		
		System.out.println("Animal can move");}
}
class Dog extends Animal
{
	void move(){	
		System.out.println("Dog can walk and run");}
}
class Main
{
	public static void main(String[] args) 
	{
		Dog obj=new Dog();
		obj.move();
	}
}   */

//Parent class and child class method signature must be same.
/*    class Animal
{
	 void move(){		
		System.out.println("Animal can move");}
}
class Dog extends Animal
{
	void move(int a){		
		System.out.println("Dog can walk and run");}
}
class Main
{
	public static void main(String[] args) 
	{
		Dog obj=new Dog();
		obj.move();
	}
}  */  

//The return type must be same for primitive types.
  /*class Animal
{
	 void move(){		
		System.out.println("Animal can move");}
}
class Dog extends Animal
{
	 int move(){		
		System.out.println("Dog can walk and run");}
}
class Main
{
	public static void main(String[] args) 
	{
		Dog obj=new Dog();
		obj.move();
	}
} */  


//Covariant return types:Changing the return type is possible for class types.
 /*
 class Animal{
	 Animal move()
	 {		
		System.out.println("Animal can move");
		Animal a=new Animal();
		return a;
		}
}
class Dog extends Animal{
	Dog move()
	{		
		System.out.println("Dog can walk and run");
		return new Dog();
	}
}
class Main{
	public static void main(String[] args) 
	{
		Dog obj=new Dog();
		obj.move();
	}
}  
 */
//Covariant return types>Example:2
/*class A{}
class B extends A{}
class Animal{
	 A move(){		
		System.out.println("Animal can move");
		return new A();}}
class Dog extends Animal{
	B move(){		
		System.out.println("Dog can walk and run");
		return new B();}}
class Main{
	public static void main(String[] args) 
	{
		Dog obj=new Dog();
		obj.move();
	}
}*/
/*
//Child class method cannot override final methods in parent class
class Animal{
	 final void move(){		
		System.out.println("Animal can move");}
}
class Dog extends Animal{
		void move(){
		System.out.println("Dog can walk and run");}
		}
class Main{
	public static void main(String[] args) 
	{
		Dog obj=new Dog();
		obj.move();
	}
}*/
//Error:overridden method is final

/*Note: final keyword is applicable for class, method and variable.
if a class is declared final> cannot be inherited
if a method is declared final> cannot be overriden
if a variable is declared final> cannot be changed/modified
Imp: For local varibales only one modifier is applicable> final*/

// use of final keyword in case of variables
/*class A
{
	public static void main(String[] args)
	{
		final int a=1;
		a=a+4;
		System.out.println(a);
	}

}*/
//Error:cannot assign a value to final variable a*/

//if a class is final, does it mean its variables are also final?
/* final class A
{
public static void main(String[] args)
	{
		int a=1;
		a=a+4;
		System.out.println(a);
	}
} 
*/
//if a class is declared as final, its methods are by default final
/* final class A
{
	 int a=1;
	 void a()
	 {
		a=a+4;
		System.out.println(a);
	}
     public static void main(String[] args){
	   A obj=new A();
		
	}
} */

//v.Imp: Parent class reference variable is able to hold child class 
//object but vice versa is not true.
//a.m1()> At compile time:compiler will check the m1 method 
//in Parent class.
//At run time, child class object is created therfore child class method 
//will be executed.
 /*class Parent{
	void a()
	  {
	  }		  
 }
class Child extends Parent{
	    
		void m2()   
		{
			System.out.println("direct method");
		}
		 void a()
		{
			 
		}
	}
class Main{
	public static void main(String[] args) {   
		Child c=new Child();		
		c.m2();
	}
} 
	*/	

/*class Bank{  
int getRateOfInterest(){return 0;}  }    
class SBI extends Bank{  
int getRateOfInterest(){return 8;}  }   
class ICICI extends Bank{  
int getRateOfInterest(){return 7;}  }  
class AXIS extends Bank{  
int getRateOfInterest(){return 9;}  }  

class Test2{  
public static void main(String args[]){  
SBI s=new SBI();  
ICICI i=new ICICI();  
AXIS a=new AXIS();  
System.out.println("SBI Rate of Interest: "+s.getRateOfInterest());  
System.out.println("ICICI Rate of Interest: "+i.getRateOfInterest());  
System.out.println("AXIS Rate of Interest: "+a.getRateOfInterest());  
}  
}  
*/
//Runtime ploymorphism

/*class Bank{  
float getRateOfInterest(){return 0;}  
}  
class SBI extends Bank{  
float getRateOfInterest(){return 8.4f;}  
}  
class ICICI extends Bank{  
float getRateOfInterest(){return 7.3f;}  
}  
class AXIS extends Bank{  
float getRateOfInterest(){return 9.7f;}  
}  
class TestPolymorphism{  
public static void main(String args[]){  
Bank b;  
b=new SBI();  
System.out.println("SBI Rate of Interest: "+b.getRateOfInterest());  
b=new ICICI();  
System.out.println("ICICI Rate of Interest: "+b.getRateOfInterest());  
b=new AXIS();  
System.out.println("AXIS Rate of Interest: "+b.getRateOfInterest());  
}  
}  */

//Method hiding:
//static modifier: m1 is a static method, a is parent 
//reference variable
//in java, it is not possible to override the static methods because
//static methods are specific to class.
/*
 class Parent{	
	static void m1()
	{		
		System.out.println("Parent method");
	}
}
class Child extends Parent{
	static void m1()   
	{
		System.out.println("Child method");
	}	
}
class Main{
	public static void main(String[] args) 
	{   
		Parent a= new Child();
		a.m1();
		//Child c= (Child)a; 
		//c.m1();
	}
}
 */
/*
class P
{
	public static void main(String [] args)
	{
		System.out.println("P");
	}
}
class C extends P
{
	public static void main(String [] args)
	{
		System.out.println("C");
	}
}	
*/

//Private method overriding
/* class Parent{	
		private void m1(){		
		System.out.println("Parent method");}
}
class Child extends Parent{
	   		
}
class Main{
	public static void main(String[] args) 
	{   
		Parent p= new Parent();
		p.m1();
		//Parent p= new Child();
		//p.m1();
	}
} */

