class Test
{
 public static void main(String[] args)
 {
	 System.out.println("Hi");
	 System.out.println(args[0] + " " + args[1] + " " +args[2]);
 }
}

class Test1
{
 public  static void  main(String[] args)
 {
	 System.out.println("Hello");
	 String[] s = new String[] {"123", "Ram", "734&%#"};
	 Test.main(s);
	 //Test.main(null);
	 

 }
}
 
