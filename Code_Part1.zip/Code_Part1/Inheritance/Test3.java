//object creation:
//It is recommended to create the object of child class.
//Because, when we create the object of child clases, it is
// possible to access the parent properties.
//Parent of C is B, Parent of B is A and Parent of A is 
//Object class
//Important: root class of all java classes is Object class.
//Every class in java is the child class of Object class 
//directly or indirectly.
//Example: B and C is the indirect child class of Object 
//class
//Object class is present in java.lang package(predefined 
//package)

class A extends Object //by default Object class is the parent 
{	
}
class B extends A	
{
}
class c extends B		
{
}