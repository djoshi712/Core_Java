// When constructors are called: Constructors are called in order of derivation
class  A 
{
	A()
	{System.out.println("A class cons");
	}
}
class B extends A
{
	B(){System.out.println("B class cons");}
}
class C extends B
{
	C(){System.out.println("C class cons");}
}
class Main
{
	public static void main(String[] args) 
	{
		C obj=new C();
	}
}
