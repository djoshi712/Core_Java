//use of super keyword
//1.It acts somewhat like "this", except that it always refers to the superclass of the subclass in which it is used.

 /* class Parent
{
	int a=10;
	int b=20;
}
class Child extends Parent
{   int x=100;
	int y=200;
	void add(int i, int j)
	{
		System.out.println(i+j);
		System.out.println(x+y);
		System.out.println(a+b);
	}
	public static void main(String [] args)
	{
		new Child().add(1000,2000);
	}
} */
 


class Parent
{
	int a=10;
	int b=20;
}
class Child extends Parent
{   int a=100;
	int b=200;
	void add(int a, int b)
	{
		System.out.println(super.a+super.b);
		System.out.println(this.a+this.b);
		System.out.println(a+b);
	}
	public static void main(String [] args)
	{
		Child obj=new Child();
		obj.add(1000,2000);
	}
}



/* 
class Parent 
{
 void m1(){System.out.println("m1 method of parent class");}
}
class Child extends Parent
{
	void m1(){System.out.println("m1 method of child class");}
	void m2()
		{
		this.m1();			
		super.m1();			
		}
	public static void main(String[] args){
	new Child().m2(); }
}
 */