//if parent class and child class contains instance block 
//then parent class instance block will be executed first.
/*
class Parent 
{	 
	{
		System.out.println("parent class instance block");
	}
}
class Ins extends Parent
{	
	{
		System.out.println("child class");
	}
	public static void main(String[] args) 
	{
		new Ins();
	}
}

*/
/*
class Parent 
{	 
	Parent(){System.out.println("parent class cons");}
	{
		System.out.println("parent class instance block");
	}
}
class Ins extends Parent
{	
	Ins(){System.out.println("child class cons");}
	{
		System.out.println("child class");
	}
	public static void main(String[] args) 
	{
		new Ins();
	}
}
*/

//Parent class static block

class Parent{	 
	static{
	System.out.println("parent class static block");
	}
	static{
	System.out.println("parent class static block 2");
	}
	Parent(){System.out.println("parent class cons");}
	{System.out.println("parent class instance block");
	}}
class Ins extends Parent
{	static{
	System.out.println("child class static block");
	}
	Ins(){System.out.println("child class cons");}
	{	System.out.println("child class instance block");}
	public static void main(String[] args) 
	{new Ins();new Ins();
	}
}
