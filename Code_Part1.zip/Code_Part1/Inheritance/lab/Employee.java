import java.util.Scanner;

class Employee 
{
	String name; int id, double salary;
	Employee()
	{
		super();
	}
	Employee(String name, int id, double salary)
	{
		this.name=name;
		this.id=id;
		this.salary=salary;
	}
	String name()
	{
		return name;
	}
	double salary()
	{
		return salary;
	}
	double increasedSalary(double per)
	{		
		salary= salary+(salary*(per/100))
		return salary;
	}
 class Manager extends Employee
 {
	 String department;
	 
	 Manager(String name, int id, double salary, String department)
	 {
		 super(name, id, salary);
		 this.department= department;
	 }

 }
 class Main
 {
	public static void main (String []args)
	 {
	/*Scanner in= new Scanner(System.in);
	for(i=0; i<10; i++){
	System.out.println("Enter you name, age and salary");

       String a= in.nextLine();
	   System.out.println("Enter you age");
       int b =in.nextInt();
	   System.out.println("Enter you salary");
       double c =in.nextDouble();
	   System.out.println("Are you a manager? Yes or No?");
	   String d =in.next();
	   String e;
	   if(d=="Yes"){
	   System.out.println("Enter you department");
        e =in.next();}
	   */
		   Manager o1= new Manager("A", 23, 24343, "CIT");
		   o1.name; o1.salary;
		   Manager o2=new Employee("") 
		
	   new Manager().name(a);
	}
	  
	 }
 }


}
