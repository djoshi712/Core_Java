class Parent
{
	int a=10;
	int b=20;
}
class Child extends Parent
{   int x=100;
	int y=200;
	void add(int i, int j)
	{
		System.out.println(i+j);
		System.out.println(this.x+this.y);
		System.out.println(super.a+super.b);
	}
	public static void main(String [] args)
	{
		new Child().add(1000,2000);
	}
}