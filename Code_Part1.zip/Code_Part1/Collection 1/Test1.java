import java.util.*;
class Test1
{
	 public static void main(String args[]) {
		 /* Object obj[]=new Object[5];
		 obj[0]=10;
		 obj[1]=10.9f;
		 obj[2]="Ram"; */
		 
		 List<Object> c= new ArrayList<>();
		 c.add(10);
		 c.add("Ram");
		 c.add(70.5f);
		 c.add(1,50);
		 c.add(1,80);
		 c.add(50);
		 c.add(50);
		 
		 Iterator i= c.iterator();
		 while(i.hasNext())
		 {
			 System.out.println(i.next());
		 }
		 
		/*  for(Object o: c)
		 {
			 System.out.println(o);
		 } */
	 }
}
		 