//
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Collections;
class Intro3
{
	public static void main(String[] args)
	{
		/* /* Collection<Integer> values= new ArrayList<Integer>();
		values.add(2);
		values.add(3);
		values.add(5);
		/*add a new element, now i want to add this after 3, but in Collection interface
		we do not have anything to specify the index number. We have other interface List in
		which provides index number 
		values.add(4); */ 
		
		List<Integer> values= new ArrayList<Integer>();
		values.add(5);
		values.add(6);
		values.add(8);
		values.add(2, 4);
		
		Collections.sort(values);
		
		for(Integer i: values)
		{
			System.out.println(i);
		}
		
	}
}