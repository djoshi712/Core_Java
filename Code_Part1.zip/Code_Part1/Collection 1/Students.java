class Students
{
	String name;
	int roll_no;
	Students(String name, int roll_no)
	{
		this.name=name;
		this.roll_no=roll_no;
	}
	
	public String toString()
	{
		return name+ " "+ roll_no;
	}
}