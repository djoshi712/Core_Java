import java.util.*;

 class test {
  public static void main(String[] args) {
 
   // ArrayList with Capacity 4
      ArrayList<String> StudentList = new ArrayList<String>();
	   Object cloneList;
      //Added 4 elements
       StudentList.add("David");
       StudentList.add("Tom");
       StudentList.add("Rohit");
       StudentList.add("Paul");
      
       System.out.println("Elements in StudentList are: ");
       System.out.println(StudentList);
  
       cloneList = StudentList.clone();
       System.out.println("Elements in cloneList are:");
       System.out.println(cloneList);
   }
}