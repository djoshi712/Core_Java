 import java.util.*;
 
  //import java.util.ArrayList;
  // import java.util.Collection;
 class test12
{
	public static void main(String[] args)
	{
		Map<String,Integer> c= new HashMap<>();
		c.put("Ram", 123);
		c.put("Shyam", 113);
		c.put("Sita", 222);
		c.put("Ravan", 420);
		
		System.out.println(c);
		System.out.println(c.get("Ram"));
		Set<String> keys= c.keySet();
		for(String key: keys)
			System.out.println(c.get(key));
		System.out.println(keys);
		
		
		//c.get("Ram");
		//Collections.sort(c);
/* 		 for(Integer i: c)
		{
			System.out.println(i);
		} 
		 */
	}	
}
		
		