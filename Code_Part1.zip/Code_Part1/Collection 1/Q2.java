import java.util.*;
class Intro
{
	public static void main(String[] args)
	{
	
		Students s[]= new Students[5];
		s[0] = new Students();
		s[1] = new Students();
		s[2] = 10;  
		s[3] = new Integer(10);  
	
		for(Students i : s)
		{
			System.out.println(i);
		} 
	}
}
class Students
{
	
}