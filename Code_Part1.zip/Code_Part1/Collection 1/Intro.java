import java.util.*;
public class Intro
{
	public static void main(String[] args)
	{
		/*
		int arr[]= new int[5];	//int array, size is fixed, homogenous elements
		
		Students s[]= new Students[5];
		s[0] = new Students("Ram", 22);
		s[1] = new Students("Shyam", 23);
		//s[2] = 10;  //primitive
		//s[3] = new Integer(10); //object 
		//s[4] = "raju"; //string
		
		for(Students i : s)
		{
			System.out.println(i);
		} 
	
		Object arr1[]= new Object[5]; //hetrogenous elements using Object array, size is fixed
		arr1[0]="Ram"; //string
		arr1[1]=10;  //int
		arr1[2]=10.3f;  //float
			
		for(Object o : arr1)
		{
			System.out.println(o);
		}
			
		//fetching values: iterator, enhanced for loop
		
		Iterator i= obj.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
		*/
		
		Collection obj= new ArrayList();
		obj.add("Ram");
		obj.add(10);
		obj.add(10.3f);
		//obj.add(1,7);
		
	//it will not work because collection doesnot have index, instead use List or Set	
		List<Integer> l= new ArrayList<Integer>();
		l.add(6);
		l.add(8);
		l.add(9);
		l.add(1,7);
		l.add(6);
		System.out.println(l);
		
	
		/*
		Set<Integer> s1= new HashSet<Integer>();
		s1.add(6);
		s1.add(8);
		s1.add(9);
		s1.add(1,7);
		//s1.add(6);
		
		Set<Integer> s2= new TreeSet<Integer>();
		s1.add(9);
		s1.add(2);
		s1.add(5);
		s1.add(1,7);
		//s1.add(6);
		
		
	//List -allows duplicate values, ordered
	//Set- doesnot allow duplicate value, unoredered
	//we get everything in sorted order if we use TreeSet
	
	
	//Map is used to have a key value relationship. Example: dictionary (name to Phone number)	
	//HashMap vs HashTable: One of them is synchronized
	
	
		Map<Integer, String> m1= new HashMap<>();
		Map<Integer, String> m2= new HashTable<>(); */	
	} 
}