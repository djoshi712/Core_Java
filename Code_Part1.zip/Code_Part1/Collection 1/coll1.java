public class Song
{
	private String songName;
	private String bandName;
	private double songPrice;
	
	//Here, song name and band name are immutable
	Song(String songName, String bandName, double songpPrice)
	{
		this.songName= songName;
		this.bandName=bandName;
		this.songPrice=songPrice;
	}
	
	public String getSongName()
	{
		return songName;
	}
	public String getBandName()
	{
		return bandName;
	}
	public double setPrice(double songPrice)
	{
		this.songPrice=songPrice;
	}				
	}
	public double getPrice()
	{
		return price;
	}
	public String toString()
	{
		return (songName + "from " + bandName + "cost Rs" +songPrice);
	}

}
	
		
		
	
		