// Java program to demonstrate working of Comparator
// interface and Collections.sort() to sort according
// to user defined criteria.
//sort(List<T> list)
//sort(List<T> list, Comparator<? super T>)
//int compare(T o1, T o2)

import java.util.*;
 
// A class to represent a student.
class Student
{
    int rollno;
    String name, address;
 
    // Constructor
     Student(int rollno, String name,
                               String address)
    {
        this.rollno = rollno;
        this.name = name;
        this.address = address;
    }
 
    // Used to print student details in main()
     public String toString()
    {
        return this.rollno + " " + this.name +
                           " " + this.address;
    } 
}
 
 class Sortbyroll implements Comparator<Student>
{
    // Used for sorting in ascending order of
    // roll number
    public int compare(Student a, Student b)
    {
        return a.rollno - b.rollno;
    }
} 
 
// Driver class
class Main
{
    public static void main (String[] args)
    {
        ArrayList<Student> ar = new ArrayList<Student>();
        ar.add(new Student(111, "bbbb", "london"));
        ar.add(new Student(131, "aaaa", "nyc"));
        ar.add(new Student(121, "cccc", "jaipur"));
 
        System.out.println("Unsorted");
      
		for(Student o : ar)
		{
			System.out.println(o);
		}
 
         Collections.sort(ar, new Sortbyroll());
 
        System.out.println("\nSorted by rollno");
        
		for(Object o : ar)
		{
			System.out.println(o);
		} 
		/* Iterator i=al.iterator();  

		while(i.hasNext())
		{  
		System.out.println(i.next());
		}   */ 
    }
}
