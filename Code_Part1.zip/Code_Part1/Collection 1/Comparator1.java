// Java program to demonstrate working of Comparator
// interface and Collections.sort() to sort according
// to user defined criteria.
//sort(List<T> list)
//sort(List<T> list, Comparator<? super T>)
//int compare(T o1, T o2)

import java.util.*;
 
class Main
{
    public static void main (String[] args)
    {
        List<Integer> c= new ArrayList<Integer>();
		c.add(100);
		c.add(103);
		c.add(606);
		c.add(407); 
		c.add(1,49);
        System.out.println("Unsorted");
      
		for(Integer i : c)
		{
			System.out.println(i);
		}
		 
         Collections.sort(c);
		 Collections.reverse(c);
 
        System.out.println("\nSorted list");
        
		for(Integer i : c)
		{
			System.out.println(i);
		}
		
		System.out.println("\nSorted according to last digit");
        
		Comparator<Integer> com= new CompImp();
		Collections.sort(c,com);
		for(Integer i : c)
		{
			System.out.println(i);
		}
    }
}
class CompImp implements Comparator
{
	public int compare(Integer o1, Integer o2)
	{
		if(o1%10>o2%10)
		return 1;	//swap
		else return 0;
	}
}

