import java.util.*;
class Test
{
	public static void main(String[] args)
	{
		/* int arr[]= new int[5];
		Object arr1[]= new Object [5];
		arr1[0]="Ram";
		arr1[1]=10.2f;
		arr1[2]=20;
		for(Object o: arr1)
		{
			System.out.println(o);
		} */
		/* Collection<Object> c= new ArrayList<>(); //ordered, allows duplicate value
		c.add("Ram");
		c.add(10.2f);
		c.add(20);
		c.add(20); */
		Collection<Integer> c= new ArrayList<>(); //ordered, allows duplicate value
		c.add(10);
		c.add(10);
		c.add(60);
		c.add(40); */
		//c.add(1,44); //not possible because Collection does not support index
		
		/* List<Integer> c= new ArrayList<>();
		c.add(10);
		c.add(10);
		c.add(60);
		c.add(40); 
		c.add(1,44); */
		
		/* Set<Integer> c= new HashSet<>(); //duplicate elements not allowed
		c.add(10);
		c.add(10);
		c.add(60);
		c.add(40); 
		
		Iterator i=c.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		} */
		 /* Student s1=new Student(101,"Ram",23);  
		Student s2=new Student(102,"Shyam",21);  
		Student s3=new Student(103,"Laxman",25); 
			
		Set<Student> stu= new HashSet<>();
		stu.add(s1);
		stu.add(s2);
		stu.add(s3);*/
		
		Iterator i=stu.iterator();  

		while(i.hasNext())
		{  
		System.out.println(i.next());
		}   
			
		
	}
}