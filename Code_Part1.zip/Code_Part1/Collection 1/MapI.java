import java.util.Map;
import java.util.Set;
import java.util.HashMap; //popular
import java.util.Hashtable;
//difference is Hashtable is synchronized but HashMap is not
class MapI
{
	public static void main(String[] args)
	{
		Map<String,String> map= new HashMap<>();
		map.put("Name", "Apple");
		map.put("Shape", "Round");
		map.put("Color", "Red");
		map.put("Name", "Orange"); //we can repeat values but not keys
		
		System.out.println(map);
		System.out.println(map.get("Name"));
		System.out.println(map.get("name"));
		
		Set<String> keys= map.keySet();
		for(String key: keys)
			System.out.println(map.get(key));
	}
}
		
	
