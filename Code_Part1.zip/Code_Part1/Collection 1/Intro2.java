//enhanced for loop
/* collection is introduced in 1.2 v and Generics in 1.5
provides us dynamic array, expand and reduce the size of array as and when required */
	
import java.util.Collection;
import java.util.ArrayList;
class Intro2
{
	public static void main(String[] args)
	{
		/* int arr[]= new int[5];	//int array
		Object arr1[]= new Object[5];	//Object array
		arr1[0]="Ram";
		arr1[1]=10; */
		
		Collection<Object> values= new ArrayList<Object>();
		values.add("Ram");
		values.add(10);
		values.add(23.4f);
		
		//retrieving elements using enhanced for loop
		for(Object o : values)
		{
			System.out.println(o);
		}
		//retrieving elements using iterator
	//Iterator is an interface, we create object of its implemented class
	}		
		
	
}	
	