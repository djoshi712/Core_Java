/* Importance of Instance blocks
Constructor logics are specific to objects but instance block is common for all the objects
*/
class Test2 {
	Test2()			//constructor with no arguments, specific for object
	{System.out.println("constructor 0 argument");
	}
	Test2(int a)		// constructor with one argument, specific for object
	{System.out.println("constructor 1 argument");
	}
	Test2(int a, int b) // constructor with two arguments, specific for obejct
	{System.out.println("constructor 2 arguments");
	}
	{		System.out.println("Instance block");//common for all objects
	}
	public static void main(String[] args) {
		new Test2();        //ins, cons
		new Test2(10);	    //ins, cons
		new Test2(10,20);	//ins, cons	, for three constructors only one same instance block is executed here.			
	}
}
