/*
>Aim: Instance block vs Constructors
>Class contain five elements:
class{
	variables (Types: local, instance, static)
	methods	  (Types: instance and static)
	constructors
	Instance blocks
	static blocks
	}
>How to call a constructor?
	a.Create the object: Various approaches are there to create the objects in java (new keyword is one of the approaches)
	b.Test1 t= new Test1(); 
	Test1	.....> class name
	t		.....> object name
	==		.....> assignment operator
	new		.....> keyword(used to create the object)
	Test1()	.....> constructor
	c.During object creation time, Test1() constructor will be executed
> Rules to declare the constructors in java:
	............................................
	a. The constructor name and class name must be same
	b. The constructor able to take parameters
	c. No return type is allowed
> Types:
	a. Default: 0 arguments, empty implementation
	b. user defined: (0 arguments, parameterized)
> Advantage of constructors: 
	a. used to write logics and logics are executed during object creation
	b. initialization of instance variable
> Advantage of instance blocks:
	a. used to write logics and logics are executed during object creation
	b. initialization of instance variable
> Syntax of instance blocks:
{
	//logics here
}
> Both are used to write the logics and executed during object creation time but instance blocks are executed first
*/
class Test1   
{
	Test1()										   //executed during object creation
	{
		System.out.println("o arg constructor");  //user defined constructor
	}	

	{
		System.out.println("Instance block");  //to call this block, we need to create the object
	}
	public static void main(String[] args)	//static method
	{
		Test1 t=new Test1();	//named object
		// or new Test1();		//nameless object to reduce the lenght of the code
		
	}
}
