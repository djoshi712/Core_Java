/* Important: Instance block execution depends on object creation but not constructors execution
*/
class Test4
{
	Test4()			
	{
		this(10);	//this is used to call another constructor of Test5 class
		System.out.println("constructor 0 argument");
	}
	Test4(int a)			
	{
		System.out.println("constructor 1 argument");
	}
	//Instance block
	{
		System.out.println("Instance block");
	}
	public static void main(String[] args) 
	{
		new Test4();				
	}
}


//Difference: instance block logics common for all objects but constructor logics are specific to different objects