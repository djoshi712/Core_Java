//Parameterized(user defined) constructors

class Test2 
{
	void m1()	//instance method
	{
		System.out.println("m1 method");
	}
	Test2()
	{
		System.out.println("empty constructor");
	}
	
	Test2(int a)
	{
		System.out.println("user defined constrcutor");
	}

	public static void main(String[] args) 
	{
		Test2 t= new Test2();
		Test2 t1= new Test2(10);
		t.m1();					//we can call m1 method using either t or t1

		
	}
}
