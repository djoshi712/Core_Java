/*Instance blocks are used to initiaize the variables

*/
class Test5 
{
	int a; 
	void display(){
		System.out.println("Hi "+ a);}
	
	{
	a=20;
	}
	
	public static void main(String[] args) 
	{
		new Test5().display();		
	}
}
