/*
1.class with multiple instance blocks is possible
2.Inside the class we can declare multiple Instance blocks but the execution order is top to bottom
*/
class Test3
{
	Test3()			
	{
		System.out.println("constructor 0 argument");
	}
	Test3(float b)			
	{
		System.out.println("constructor 1 argument");
	}
	{
		System.out.println("Instance block 1");
	}
	{
		System.out.println("Instance block 2");
	}
	public static void main(String[] args) 
	{
		new Test3();
		new Test3(12.5f);				
	}
}

