/*
-Implements Set Interface.
-Underlying data structure for HashSet is hashtable.
-As it implements the Set Interface, duplicate values are not allowed.
-Objects that you insert in HashSet are not guaranteed to be inserted 
in same order. Objects are inserted based on their hash code.
-NULL elements are allowed in HashSet.
-HashSet also implements Searlizable and Cloneable interfaces.
-Initial Capacity: 16
-Load Factor: The load factor is a measure of how full the HashSet is 
allowed to get before its capacity is automatically increased. 
If internal capacity is 16 and load factor is 0.75 then, number of 
buckets will automatically get increased when the table has 12 elements 
in it.
-Internal working of a HashSet
All the classes of Set interface internally backed up by Map. 
HashSet uses HashMap for storing its object internally. 
Actually the value we insert in HashSet acts as key to the map Object
and for its value java uses a constant variable. So in key-value pair
all the keys will have same value.
private transient HashMap map;

// Constructor - 1
// All the constructors are internally creating HashMap Object.
public HashSet()
{
    // Creating internally backing HashMap object
    map = new HashMap();
}

// Constructor - 2
public HashSet(int initialCapacity)
{
    // Creating internally backing HashMap object
    map = new HashMap(initialCapacity);
}

// Dummy value to associate with an Object in Map
private static final Object PRESENT = new Object();

public boolean add(E e)
{
   return map.put(e, PRESENT) == null;
}

/*
-Set: dupliates not allowed, insertion order not preserved
-does not contain any new methods
-DS: Hashtable
-add("A") //returns false on adding duplicate objects
https://www.geeksforgeeks.org/internal-working-of-sethashset-in-java/
-based on hashcode, orders are inserted
-hetreogeous allowed, null allowed, Serialiizable, coloneable not RA
- best for Search operation
-Constructor:
1. HashSet s= new HashSet() 
//default capacity 16, default fill ratio(load factor)- 0.75
2. HashSet h= new HashSet(int initial capacity);
3. HashSet h= new hashset(int initial capacity, float load_factor)
LinkedhashSet: duplicates not allowed, insertion order preserved
-DS : combination of hashtable+linked list
-1.4v
https://codepumpkin.com/hashset-internal-implementation/

*/
import java.util.LinkedHashSet;
import java.util.HashSet;
class HashSet1{ 
  public static void main(String[] args) {
      HashSet hset = new HashSet();
      hset.add("Apple");
      hset.add("Mango");
	  hset.add(30);
      System.out.println(hset.add(30));
      hset.add(30);
      hset.add(10.5f);
      System.out.println("Before: HashSet contains: "+ hset);
      hset.clear();
      System.out.println("After: HashSet contains: "+ hset);
	 
	 LinkedHashSet h = new LinkedHashSet();
      h.add("Apple");
      h.add("Mango");
	  h.add(30);
      System.out.println(hset.add(30));
      h.add(30);
      h.add(10.5f);
      System.out.println("Before: LinkedHashSet contains: "+ h);
	  h.clear();
      System.out.println("After: HashSet contains: "+ h);
  }
}


