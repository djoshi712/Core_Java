/*Hashmap:
-HashMap is a part of Java’s collection since Java 1.2. 
-It provides the basic implementation of Map interface of Java. 
-It stores the data in (Key, Value) pairs. 
-To access a value one must know its key. 
-HashMap is known as HashMap because it uses a technique called Hashing. 
-Hashing is a technique of converting a large String to small String that
represents the same String. 
-A shorter value helps in indexing and faster searches. 
-HashSet also uses HashMap internally. 
-It internally uses a link list to store key-value pairs
-Internally HashMap contains an array of linkedlist and a node is 
represented
 as a class which contains 4 fields :
int hash
K key
V value
Node next

class Entry<K, V> {
    final K key;
    V value;
    Entry<K, V> next;
    public Entry(K key, V value, Entry<K, V> next) {
        this.key = key;
        this.value = value;
        this.next = next;
    }
    // getters, equals, hashCode and toString
}https://medium.com/@mr.anmolsehgal/java-hashmap-internal-implementation-21597e1efec3
*/


import java.util.HashMap; 
import java.util.Map; 
  
class GFG 
{ 
    public static void main(String[] args)  
    { 
      
        HashMap<String, Integer> map = new HashMap<>(); 
          
        System.out.println(map); 
        map.put("vishal", 10); 
        map.put("sachin", 30); 
        map.put("vaibhav", 20); 
		System.out.println(map.put("vaibhav", 50));         
        System.out.println("Size of map is:- " + map.size());       
        System.out.println(map); 
		
        if (map.containsKey("vishal"))  
        { 
            Integer a = map.get("vishal"); 
            System.out.println("value for key \"vishal\" is:- " + a); 
        } 
          
        map.clear(); 
        System.out.println(map); 
    } 
      
    /* public static void print(Map<String, Integer> map)  
    { 
        if (map.isEmpty())  
        { 
            System.out.println("map is empty"); 
        } 
          
        else
        { 
            System.out.println(map); 
        } 
    } */ 
} 