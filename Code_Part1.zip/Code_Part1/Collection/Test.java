class Test{
public static void main(String[] args)
{
Object obj= new Object()
{
public int hashcode()
{
System.out.println("Hi");
}
};

}
}