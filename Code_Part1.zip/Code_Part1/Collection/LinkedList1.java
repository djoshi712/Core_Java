import java.util.*;  
public class LinkedList1{  
 public static void main(String args[]){  
 
  LinkedList al=new LinkedList();  
  al.add("Ravi");  
  al.add(null);  
  al.add(10);  
  al.add("Ajay");  
  
  Iterator itr=al.iterator();  
  while(itr.hasNext()){  
  System.out.println(itr.next());  
  }  
 }  
}  