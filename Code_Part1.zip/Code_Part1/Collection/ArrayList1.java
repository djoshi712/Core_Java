/* 
-if we need to transfer objects from one place to another in a network,
the object has to be serializable 
-Every collection class implements Serializable and Cloneable interface
-AL and Vector class implements RandomAccess interface but not LL
-LL is best choice if our frequent operation is insertion or deletion
in the middle
-LL is worst choice if our frequent operation is retrievel
-to provide support for stack, queue operations, LL has six specific 
methods, addFirst, addLast, getLast, getFirst, removeLast, removeFirst
-Constructor: AL l= new AL() //capacity required
LL l= new LL() //capacity concept missing here
-Stack is subclass of Vector and  specially designed for LIFO operation
(push(Object o), pop(), empty()etc.)
-difference between AL and Vector
-most of the methods in Vector is synchronized,
and all methods are non synchronized in AL
-to get synchronized version of All collection objects use,
public static List synchronizedList(List l);
 */
/*
import java.util.*;
class ArrayList1 {
	public static void main(String[] a){
		Collection c= new ArrayList<Integer>();
		c.add(5);
		c.add(6);
		
		ArrayList al = new ArrayList();
		LinkedList l = new LinkedList();
		//System.out.println(al instanceof RandomAccess);
		//System.out.println(l instanceof RandomAccess);	
		
		al.add("JAVA");
		al.add(10);
		al.add(12.7);
		al.add(18.5f);
		al.add(0,null);
		al.addAll(2, c);
		
		System.out.println(al);
		System.out.println(al.get(1)); 
		System.out.println(al.contains("JAVA")); 
		System.out.println(al.isEmpty());
		System.out.println(al.indexOf(10)); 
		System.out.println(al.size());

		
		l.add("JAVA");
		l.add(2);
		l.add(3.4f);
		l.set(0, "chinna");
		l.addAll(2, c);
		l.addFirst("AAAA");
		l.addLast("ZZZZ");
		System.out.println(l);		
		
		
		Vector v = new Vector(); 
		System.out.println(v.capacity()); //10
		for (int i = 0;i<10 ;i++ )
		{
		v.addElement(i);
		}
		System.out.println(v.capacity()); //10
		v.addElement("Aa");
		System.out.println(v.capacity());
		System.out.println(v);
		
		Stack s= new Stack();
		s.push("A");
		s.push("B");
		s.push("C");
		System.out.println(s);
		System.out.println(s.pop()); 
		System.out.println(s.search("A")); 
		System.out.println(s.empty());	 
	}
}
*/

/*Three cursors of Java (used to retrieve objects one by one
1. Enumeration: used to retrieve objects one by one from old collection objects
Enumeration e= v.elements(); // v is any vector object
methods: hasMoreElemeents(), nextElement()
-support: read operation
2. Iterator
-Collection contains iterator method to get iterator object
public Iterator iterator()
-to overcome enumeration limitations, we use iterator 
-universal cursor
-supports: read+remove operation
-Limitations: cannot iterate in backward direction
3. ListIterator
-applicable only for List objects
-iterate in both directions
-supports: read+remove+replace+addition of new objects operation
public ListIterator listIterator(); //available in List interface
ListIterator litr= l.listIterator(); //l is any list object
-ListIterator is child interface of Iterator
-methods: hasPrevious(), previous()

*/

import java.util.Enumeration;
import java.util.Vector;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.ListIterator;

 class ArrayList1 {
	public static void main(String a[]){
		/*
		Vector v= new Vector();
		for(int i=1; i<= 10; i++)
		{
			v.addElement(i);
		}
		System.out.println(v);
		Enumeration itr= v.elements();	//elements method is present in Collection interface
		while(itr.hasMoreElements()){
			Integer i= (Integer) itr.nextElement();
			if(i%2==0)
			System.out.println(i);		
		}
		System.out.println(v);
		*/
		
		/*
		ArrayList a1= new ArrayList();
		for(int i=1; i<= 10; i++)
		{
			a1.add(i);
		}
		System.out.println(a1);
		Iterator itr= a1.iterator();	 //iterator method is present in Collection interface
		while(itr.hasNext()){
			Integer i= (Integer) itr.next();
			if(i%2==0)
			System.out.println(i);	
			else
			itr.remove();				
		}
		System.out.println(a1);
		*/
		
		LinkedList l1= new LinkedList();
		l1.add("Ram");
		l1.add("Sita");
		l1.add("10");
		l1.add("java");
		System.out.println(l1);
		ListIterator itr= l1.listIterator();	 
		while(itr.hasNext()){
			String s= (String) itr.next();
			if(s.equals("10"))
				itr.remove();	
			else if(s.equals("java"))
				itr.add("subject");
			else if(s.equals("Ram"))
				itr.set("Geeta");			
		}	
		System.out.println(l1);
		
		
		
		/*while(litr.hasPrevious())
				{
				String s1= (String) litr.previous();
				if(s1.equals("Sita"))
				litr.set("Laxman");
				} 
		System.out.println(l1);*/
		
		//System.out.println(litr.getClass().getName());
		//System.out.println(itr.getClass().getName());
		//System.out.println(e.getClass().getName());
		
		
	}
}

//Create duplicate object of an ArrayList instance.
/*import java.util.ArrayList;
 class ArrayList1 {
	 
    public static void main(String a[]){
        ArrayList arrl = new ArrayList();
        arrl.add(20);
        arrl.add("Second");
        arrl.add("Third");
        arrl.add("Random");
        System.out.println("Actual ArrayList:"+arrl);
        ArrayList copy = (ArrayList) arrl.clone();
        System.out.println("Cloned ArrayList:"+copy);
    }
}*/

//Reverse ArrayList content
//We can reverse the content by calling Collections.reverse() method. 
//We have to pass ArrayList instance to this method, which reverses the 
//content.
/*
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Collections;
public class ArrayList1 {

	public static void main(String a[]){
		ArrayList<String> list = new ArrayList<String>();
		list.add("Java");
		list.add("PHP");
		list.add("Python");
		list.add("Ruby");
		list.add("C");
		System.out.println("Results before reverse operation:"+list);
		Collections.reverse(list);
		System.out.println("Results after reverse operation:"+list);
		
	}
}*/


