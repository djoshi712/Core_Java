import java.util.*;
class LinkedListEx1
{
public static void main(String[] args)
{
LinkedList l= new LinkedList();
l.add("java");
l.add(10);
l.add("java");
l.add(null);
l.set(0, "PHP");
l.add(2,"javascript");
l.removeLast();
l.addFirst("Language");
System.out.println(l);
}
}

