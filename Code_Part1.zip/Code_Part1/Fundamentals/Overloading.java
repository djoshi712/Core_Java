 /* public class Sum { 
    public int sum(int x, int y) 
    { 
        return (x + y); 
    } 
    public int sum(int x, int y, int z) 
    { 
        return (x + y + z); 
    }   
    public double sum(double x, double y) 
    { 
        return (x + y); 
    } 
    public static void main(String args[]) 
    { 
        Sum s = new Sum(); 
        System.out.println(s.sum(10, 20)); 
        System.out.println(s.sum(10, 20, 30)); 
        System.out.println(s.sum(10.5, 20.5)); 
    } 
} 
  */

/*We don’t have to create and remember different names for 
functions doing the same thing. For example, in our code, 
if overloading was not supported by Java, we would have to 
create method names like sum1, sum2, … or sum2Int, sum3Int,
 … etc.*/
 
 // Can we overload methods on return type?
//We cannot overload by return type. This behavior is same 
//in C++. Refer this for details


/* public class Main { 
    public int foo() { return 10; } 
  
    public char foo() { return 'a'; } 
  
    public static void main(String args[]) 
    { 
    } 
}  */


  class Test { 
  
    public static void main(String[] args) 
    { 
        System.out.println("Hi Geek (from main)"); 
        Test.main("Geek"); 
    } 
    public static void main(String arg1) 
    { 
        System.out.println("Hi, " + arg1); 
        Test.main("Dear Geek", "My Geek"); 
    } 
    public static void main(String arg1, String arg2) 
    { 
        System.out.println("Hi, " + arg1 + ", " + arg2); 
    } 
}   