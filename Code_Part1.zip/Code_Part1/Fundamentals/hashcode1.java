/* hashCode()
The hashCode of an Object just represents a random number
which can be used by JVM while saving/adding Objects into 
Hashsets, Hashtables or Hashmap.
hashCode() of Object class implemented to return hashCode 
based on address of an object, but based
on our requirement we can override hashCode() to generate 
our own numbers as hashCodes */
/* 
 class Test
{
	int i;
	Test(int i)
	{
	this.i = i;
	}
	 public int hashCode()
	{
	return i;
	} 
	public static void main(String arg[])
	{
	Test t1 = new Test(100);
	Test t2 = new Test(110);
	System.out.println(t1.toString()); 
	System.out.println(t2); 
	}
}  
 */ 
class hashCodeDemo
{
int i;
hashCodeDemo(int i)
{
this.i = i;
}
// public int hashCode()
// {
// return i;
// }

public static void main(String arg[])
{
hashCodeDemo h1 = new hashCodeDemo(100);
hashCodeDemo h2 = new hashCodeDemo(110);
System.out.println(h1); 
System.out.println(h2); 
} 
}