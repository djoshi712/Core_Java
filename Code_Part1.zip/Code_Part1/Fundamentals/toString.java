class Student
{
	String name;
	int rollno;
	
	Student(String name,int rollno)
	{
		this.name = name;
		this.rollno = rollno;
	}
	void calculate_cgpa()
	{
		this.num_subjects();
	}
	void num_subjects()
	{

	}
	public static void main(String arg[])
	{
		Student s1 = new Student ("raju", 101);
		Student s2 = new Student ("giri", 102);
		System.out.println(s1); 
		System.out.println(s2); 
		s1.calculate_cgpa();
	}	
		
	public String toString()
	{
		return name+"-------"+rollno;
	}  
		 
}

/* When ever we are passing object reference as argument to s.o.p() internally JVM will call toString()
on that object.
If we are not providing toString() then Object class toString() will be executed which is implemented
as follows
public String toString()
{
return getClass.getName() + ‘@’ + Integer.toHexString(hashcode);
}
Based on our requirement to provide our own String representation we have to override toString()
Ex:
If we are printing Student Object reference to return name & roll no we have to override
toString() as follows
public String toString()
{
return name+"--------"+rollno;
}
If we can place this toString() in student class then the O/P is
raju-----101
giri-----102
It is highly recommended to override toString() in our classes.


 */