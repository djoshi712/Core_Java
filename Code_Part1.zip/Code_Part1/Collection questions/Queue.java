// https://www.youtube.com/watch?v=l5TB6Jj-yTU&t=1000s
//https://docs.oracle.com/javase/7/docs/api/java/util/Queue.html
// insertion order is preserved in linkedlist and priorityqueue
// duplicates are allowed in both
// LL--> hetroigenous data is allowed but PQ stores only homogenous data
class QueueExample
{

}