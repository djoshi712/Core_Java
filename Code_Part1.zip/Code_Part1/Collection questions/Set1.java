//check if duplicates exists in collection
//https://javaconceptoftheday.com/how-hashset-works-internally-in-java/
import java.util.Set;
import java.util.HashSet;
class Solution
{
    public static void main(String[] args)
    {
        int[] nums= new int[]{1,2,3,1,4};
        HashSet<Integer> set= new HashSet<Integer>();
        for(int num: nums) 
        {
            if(set.contains(num)) System.out.println(num + " already exist in the array");
            set.add(num);
        }
        System.out.println(set);
    }
}
