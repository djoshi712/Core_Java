import java.io.*;
import java.util.*;

public class Solution {

    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int n= sc.nextInt();
        ArrayList[] a= new ArrayList[n];
        for(int i=0; i<n ; i++)
        {
            //create arraylist objects inside array
            a[i]= new ArrayList();
            //take no if items to be inserted inside the arraylist one by one
            int d= sc.nextInt();
            for (int j=0; j<d; j++)
            {
                a[i].add(sc.nextInt());
            }
        }

        
        //input no of queries
        int q=sc.nextInt();
        for(int k=0; k<q;k++)
        {
            int i= sc.nextInt();
            int  j= sc.nextInt();
            try
            {
                System.out.println(a[i-1].get(j-1));
            }
            catch(Exception e)
            {
                System.out.println("ERROR!");
            }
        }
    }
     
    }