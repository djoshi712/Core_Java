// https://www.youtube.com/watch?v=oAp4GYprVHM

import java.util.*;
class Laptop
{
    private String brand;
    private int ram;
    private int price;

    Laptop(String brand, int ram, int price)
    {
        this.brand= brand;
        this.ram= ram;
        this.price= price;
    }
    public String getBrand()
    {
        return brand;
    }
    public int getRam()
    {
        return ram;
    }
    public int getPrice()
    {
        return price;
    }


}

 class Runner
{
    public static void main(String[] args)
    {
        List<Laptop> laps= new ArrayList<>();
        laps.add(new Laptop("Dell", 16, 800));
        laps.add(new Laptop("HP", 4, 600));
        laps.add(new Laptop("Apple", 12, 1800));
        
        Collections.sort(laps);
    }

}