// https://www.youtube.com/watch?v=hbXpzOER270
//comparator vs comparable

/*import java.util.*;
class Laptop 
{
    private String brand;
    private int ram;
    private int price;

    Laptop(String brand, int ram, int price)
    {
        this.brand= brand;
        this.ram= ram;
        this.price= price;
    }
    public String getBrand()
    {
        return brand;
    }
    public int getRam()
    {
        return ram;
    }
    public int getPrice()
    {
        return price;
    }


}

public class Runner
{
    public static void main(String[] args)
    {
        List<Laptop> laps= new ArrayList<>();
        laps.add(new Laptop("Dell", 16, 800));
        laps.add(new Laptop("HP", 4, 600));
        laps.add(new Laptop("Apple", 12, 1800));
        
        Collections.sort(laps);
    }

}
*/
// https://www.youtube.com/watch?v=oAp4GYprVHM
//comparator vs comparable

import java.util.*;
class Laptop implements Comparable<Laptop>
{
    private String brand;
    private int ram;
    private int price;
     
    //compareTo()

    public int compareTo(Laptop lap2)
    {
        //return 0 if equal, 1, -1
        return this.ram-lap2.ram;
        
    }

    public String toString()
    {
        return this.brand + " " +this.ram + " " +this.price;
    }

    Laptop(String brand, int ram, int price)
    {
        this.brand= brand;
        this.ram= ram;
        this.price= price;
    }
    public String getBrand()
    {
        return brand;
    }
    public int getRam()
    {
        return ram;
    }
    public int getPrice()
    {
        return price;
    }

}

public class Runner
{
    public static void main(String[] args)
    {
        List<Laptop> laps= new ArrayList<>();
        laps.add(new Laptop("Dell", 16, 800));
        laps.add(new Laptop("HP", 4, 600));
        laps.add(new Laptop("Apple", 12, 1800));
        laps.add(new Laptop("sd", 4, 600));
        laps.add(new Laptop("wefed", 32, 1800));
        System.out.println(laps);
        Collections.sort(laps);
        System.out.println(laps);
    }

}