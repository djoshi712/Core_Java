import java.util.*;
class Laptop implements Comparable<Laptop>
{
    private String brand;
    private int ram;
    private int price;
     
    //compareTo()

    public int compareTo(Laptop lap2)
    {
        //return 0 if equal, 1, -1
        return this.getRam()-lap2.getRam();
        
    }

    public String toString()
    {
        return this.brand + " " +this.ram + " " +this.price;
    }

    Laptop(String brand, int ram, int price)
    {
        this.brand= brand;
        this.ram= ram;
        this.price= price;
    }
    public String getBrand()
    {
        return brand;
    }
    public int getRam()
    {
        return ram;
    }
    public int getPrice()
    {
        return price;
    }

}

class Main{
    public static void main(String[] args)
    {
        List<Laptop> lap= new ArrayList<>();
        lap.add(new Laptop("Dell", 32, 300));
        lap.add(new Laptop("hp", 16, 500));
        lap.add(new Laptop("acer", 12, 700));
        lap.add(new Laptop("A", 4, 500));
        lap.add(new Laptop("B", 4, 800));
        System.out.println(lap);
        Collections.sort(lap);
        System.out.println(lap);

    }
}