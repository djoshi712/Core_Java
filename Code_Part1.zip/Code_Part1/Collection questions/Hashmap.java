//https://www.youtube.com/watch?v=7k0VYHuUF6g
import java.util.*;
import java.io.*;

class Solution{
	public static void main(String []argh)
	{
			Scanner scanner = new Scanner(System.in);
	        int numOfEntries = scanner.nextInt();
	        scanner.nextLine();
        
        // Create map to store associations
            Map<String, Integer> phoneBook = new HashMap<>();
        
        // Fill map from stdin
            for(int i=0; i<numOfEntries; i++){
                String name=scanner.nextLine();
                int phone=scanner.nextInt();
                scanner.nextLine();
                phoneBook.put(name, phone);
            }
        
        // For each querry
		while(scanner.hasNext()){
            // Read querry
			String querry = scanner.nextLine();
            // If querry association exists - print
            if (phoneBook.get(querry) != null)
            {
                System.out.println(querry + "=" + phoneBook.get(querry));
            }
            else 
            { 
                System.out.println("Not found");
            }
		}
	}
}