//leetcode Q no.217
import java.util.Set;
import java.util.HashSet;
class Solution
{
    public static void main(String[] args)
    {
        //int nums[] = new int[]{1,2,1,2,3,5,6,7};
        int nums[] = new int[]{1,2,3};
        if(checkDuplicates(nums))
        System.out.println("set contains dulplicates");
    }

    public static boolean checkDuplicates(int[] nums)
    {
        Set<Integer> set= new HashSet<>();

        for (int num: nums){
            if (set.contains(num)) return true;
            else
            set.add(num);
        }
    return false;
    }
}
