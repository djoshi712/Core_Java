
import java.util.Scanner;

class Solution 
{
    public static void m1(int[] a, int n)
    {
        Scanner scan = new Scanner(System.in);

        for(int i=0; i<n; i++)
        {
            a[i] =scan.nextInt();    
        } 
       
    }

    public static void main(String[] args) 
    {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int[] a= new int[n];
        m1(a, n);
        for(int i=0; i<n; i++)
        {
            System.out.println(a[i]);   
        } 
        scan.close();

    }
}
     
       
       