import java.io.*;
import java.util.*;

public class Solution {

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int N = in.nextInt();
        List<Integer> L = new ArrayList<Integer>(N);
        for(int i = 0; i < N; i++) {
            L.add(in.nextInt());
        }

        int Q = in.nextInt();
        for(int i = 0; i < Q; i++) {
            String s = in.next();
            if(s.equals("Insert")) {
                int x = in.nextInt();
                int y = in.nextInt();
                L.add(x, y);
            } else {
                L.remove(in.nextInt());
            }
        }
        for(int i : L) {
            System.out.print(i + " ");
        }
        
    }
}