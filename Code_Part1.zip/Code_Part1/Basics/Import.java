
//Fully qualified name:
//compile time error:It means compiler unable to find where this symbol or variable is present. 
//it increases the length of the code and reduces readibility.
//we can solve this problem by using import statement.
//whenever we are writing import statement, it is not required to use fully qualified name everytime.
//Types of import statement: Implicit and explicit
//Implicit and Explicit class import
//Example> Explicit: import java.util.ArrayList(import required classes)
//Example> Implicit: import java.util.* (import all the classes)
//Highly recommended to use explicit class import because it improves readibility of the code. 

/*import java.util.ArrayList;
class Import 
{
	public static void main(String[] args)
	{
	 ArrayList obj=new java.util.ArrayList(); //cannot find symbol: Class ArrayList
	 //System.out.println(ArrayList); //cannot find symbol: Variable ArrayList
	}
}*/

//while resolving class names, compiler prioritize in the given order:
//1. explicit class import
//2. classes present in current working directory called as default package
//3. Implicit class import
//Here util package date will be considered by compiler.
//Imp: whenever we are importing a java package, all classes and interfaces present in that package by default available. but not subpackage classes. If we want to use subpackage class, we have to write import statement until subpackage level.

/*import java.util.Date;
import java.sql.*;
class Import 
{
	public static void main(String[] args)
	{
	 Date obj=new Date(); //cannot find symbol: Class ArrayList
	 System.out.println(obj.getClass().getName()); 
	}
}*/

//java.lang package and default(current working directory) package are by default present in every java program.
/*class Import 
{
	public static void main(String[] args)
	{
	 Experiment obj=new Experiment(); 
	 obj.display();
	}
}*/


//import statements are compiled time related concept not execution time. if more number of imports is present then more will be the compiled time. But, there is no effect on execution time.
//Load on fly/demand or Dynamic include:
//Differnce between C language #include and java language import statement:
//all imput/output header files are loaded at the beginning using #include at translation time. Hence it is static include.
//But, in case of java import statment no .class file will be laoded at the beginning. whenever we are using a particular class then only corresponding .class file will be loaded. (Dynamic include or load on demand/fly)
