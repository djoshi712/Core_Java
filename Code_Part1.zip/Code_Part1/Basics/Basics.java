/*1. Source file has no public class then save it  any file name
2. At most one class can be declared as public in Java. If a class is 
public then name of the program should be class_name.java otherwise we 
will get compile time error
3.class file name depends on the class name not the name 
of the file.*/

//Source file has no public class then save it with any file name
/*
class A
{
}
class B
{
	
}
 class C
{

}

class D
{
	public static void main(String[] args)
	{
	 System.out.println("Learn Java");
	}
}

/* 
/* //At most one class can be declared as public in Java. if there is a public class,the name of the program and name of the public class must be same.
class A
{
 
}
class B
{
	
}
 class C
{

}
/* 
public class Basics
{
	public static void main(String[] args)
	{
	 System.out.println("Learn Java");
	}
}
*/
//After compilation of java program, for every class a separate .class file is generated. 
class A
{
 public static void main(String[] args)
	{
	 System.out.println("Class A");
	}
}
class B
{
	public static void main(String[] args)
	{
	 System.out.println("Class B");
	}
}
class C
{
public static void main(String[] args)
	{
	 System.out.println("Class C");
	}
}

 class D
{
	
}


/*
//
class Basics
{
 public static void main(String[] args)
	{
	 ArrayList obj= new ArrayList();
	 System.out.println("Arraylist");
	}
} */
 