// static import method
/*class Mat 
{
	public static void main(String[] args) 
	{
		int a= (int)Math.sqrt(2); //double to int conversion
		System.out.println(a);
		System.out.println(Math.sqrt(2));
	}
}*/
/*import static java.lang.Math.*;
class Mat 
{
	public static void main(String[] args) 
	{
		int a= (int) sqrt(2); //double to int conversion
		System.out.println(a);
		System.out.println(sqrt(2));
	}
}*/

/*import  static java.lang.System.*;
class Mat 
{
	public static void main(String[] args) 
	{
		out.println("Hi");
	}
}*/

//ORDER: current class static member> explicit static member> implicit static member 
/*
import static java.lang.Integer.MAX_VALUE;
import static java.lang.Byte.*;
class Mat 
{
	static int MAX_VALUE=999;
	public static void main(String[] args) 
	{
		System.out.println(MAX_VALUE);
	}
}*/

//ORDER: 

/*class Mat 
{
	int MAX_VALUE=999;
	public static void main(String[] args) 
	{
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Byte.MAX_VALUE);
	}
}*/
