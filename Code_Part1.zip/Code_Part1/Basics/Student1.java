class Student extends Object
{
	int age;
	String name;	
	 public String toString()
	{
		return name+"..."+age;
	} 
}
class Main extends Object
{	
	public static void main(String[] args)
	{
		Student s1= new Student();
		String s2= new String("HI");
		System.out.println(s1.toString());
		System.out.println(s2.toString());
	}
}