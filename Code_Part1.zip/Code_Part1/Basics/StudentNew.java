class Student 	
{
	//instance variables
	int age;
	String name;	
	Student(int age, String name, Student s)
	{	
		s.age=age;
	}	
	Student()
	{	
		super();
	}	
	public  String toString()
	{
		return name + "..." +age;
	} 			
}
class Main1 extends Object
{

	public static void main(String[] args)
	{
		Student s1 = new Student();
		Student s1 = new Student(10, "Ram", s1);
		//Student s2= new Student(20, "Sita"); 
		//Student s3= new Student(); 
		System.out.println(s1.age); 
		//System.out.println(s2.age); 
	}
	
}
	
