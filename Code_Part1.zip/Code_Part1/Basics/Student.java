class Student
{
	
	
	public static void main(String[] args)
	{
		int a=10;
		byte b= (byte) (a+10);
		System.out.println(b);
	}
}
	
	
