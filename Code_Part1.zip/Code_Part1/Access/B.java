class A
{
    public void methodOfA()
    {
        System.out.println("Class A");
    }
}
 
class B extends A
{
  
    void methodOfA()
    {
        System.out.println("Class B");
    }
}