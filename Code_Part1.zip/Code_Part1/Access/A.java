class A 
{
	public static void main(String[] args) 
	{
		int x;
		System.out.println(x);
	}
}

class A
{
	public static void main(String[] args) 
	{
	    int x;
		System.out.println("Hi");
	}

}
class A
{
	public static void main(String[] args) 
	{
	    final int x;
		System.out.println("Hi");
	}
}*/

/* class A
{
	public static void main(String[] args) 
	{
	    m1(10,20);
	}
	public static void m1(final int x, int y) 
	{
	    x=100;
		y=30;
		System.out.println(x+"........."+y);

	}

} */