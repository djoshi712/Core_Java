package mypack;  
class Pack
{  
 public static void main(String args[]){  
 System.out.println("Welcome to package");  
}  
} 