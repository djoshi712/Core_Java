class Student{
    String name;
	int rillno;
	int marks;
	static String CName;
	String getStudentInfo()
	{
	 return name;
	}
	static String getCollegeInfo()
	{
	 return CName;
	}	
	public static void main(String [] args)
	{
		getCollegeInfo();
		Student a=new Student();
		a.getStudentInfo();
	}}



//public members:
//if a member is declared as public then we can access that member from 
//anywhere, but corresponding class should be visible(public)
/*package pack1;
public class Test
{
	public void m1()
	{
	System.out.println("Hi");
    }
}*/

//default class
/*package pack1;
public class Test
{
	 void m1()
	{
	System.out.println("Hi");
    }
}*/