/*
Advantage of constructors: To initialize the instance variables (maximum use)
Disadvantge in the given example: Here object is created but default value is printed. To overcome this, declare the constructor and assign some values to the object. 
*/

class Test4 
{
	int eno;
	String ename;
	float esalary;
	void display(){
		System.out.println("emp name= " +ename);
		System.out.println("emp no= " +eno);
		System.out.println("emp salary " +esalary);}
	public static void main(String[] args) 
	{
		Test4 obj= new Test4();		
		obj.display();	
	}
}


//Here constructor is used to initialize some values to instance variable during object creation.
//when we create a single object then the given code is fine but not when we want to create more then 2 objects.
/*
class Test4{
	int eno;
	String ename;
	float esalary;
	Test4(){						//executed during object creation
		eno= 121;
		ename= "arjun";
		esalary= 50000.50f;}
	void display(){
		System.out.println("emp name= " +ename);
		System.out.println("emp no= " +eno);
		System.out.println("emp salary= " +esalary);}
	public static void main(String[] args){
		Test4 obj1= new Test4();
		obj1.display();
		Test4 obj2= new Test4();
		obj2.display();}
}
*/

 //use parameterized constructors to overcome the above problem
 /*
class Test4{
	int eno;
	String ename;
	float esalary;
	Test4(int a, String b, float c){		//local variables, scope is within the block it is defined
		eno=a;
		ename=b;
		esalary=c;
		}
	void display(){
		System.out.println("emp name= " +eno);
		System.out.println("emp no= " +ename);
		System.out.println("emp salary= " +esalary);
		}
	public static void main(String[] args){
		Test4 obj= new Test4(121, "arjun", 50000.50f);
		Test4 obj1=new Tes4(111, "abc", 784638);
		obj.display();}
}
*/
//Important: usage of this keyword (Instance variable can be accessed throughout the application)
/*
class Test4{
	int eno;
	String ename;
	float esalary;
	Test4(int eno, String ename, float esalary){		//local variables, scope is within the block it is defined
		this.eno=eno;		//converting local variable to instance variable using this keyword
		this.ename=ename;
		this.esalary=esalary;}
	void display(int eno, String ename, float esalary){
		System.out.println("emp name= " +eno);
		System.out.println("emp no= " +ename);
		System.out.println("emp salary= " +esalary);}
	public static void main(String[] args){
		Test4 obj1= new Test4(121, "arjun", 50000.50f);
		obj1.display();
		Test4 obj2= new Test4(122, "meera", 60000.50f);
		obj2.display();}}
		*/