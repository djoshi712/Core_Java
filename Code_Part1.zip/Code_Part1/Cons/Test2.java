/*
user defined constructor:
1) Important: Inside the class if we are not declaring atleast one constructor, then only compiler will generate default constructor.
*/
class Test2{
	Test2(int a)
		{
			System.out.println("1 arg const");
		}
	
	public static void main(String[] args){
		Test2 obj=new Test2();       
		Test2 obj1=new Test2(10);} 
}