/* user defined constructor:
Rules:
1) the costructor name and class name must be same
2) the construtor is able to take parameters
3) while declaring constructor, no return type is allowed
*/
class Test1{
	void m1()
	{
		System.out.println("m1 method");
	}
	Test1()
	{
		System.out.println("0 arg const");
	}
	Test1(int a)
		{
			System.out.println("1 arg const");
		}
	public static void main(String[] args)
	{
		Test1 obj=new Test1();   
		Test1 obj1=new Test1(10);
		obj.m1();				 
		obj1.m1();
	}
}
