class Test8
{
	Test8(){
		Test8 obj=new Test8(100); 
		Test8(10);				
		this(10);				
		System.out.println("0 arg constructor");}
	Test8(int a){
		//this(10,20);	
		System.out.println("1 arg constructor");}
	Test8(int a, int b){
		System.out.println("2 arg constructor");}

	public static void main(String[] args){
		Test8 obj1= new Test8();}

}