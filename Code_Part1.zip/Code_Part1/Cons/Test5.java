//use of this
//https://www.javatpoint.com/this-keyword
/*Constructor calling
use this keyoword to call the constructor
*/
/*
class Test5
{
	Test5(){
		System.out.println("0 arg constructor");}
	Test5(int a){
		System.out.println("1 arg constructor");}
	Test5(int a, int b){
		System.out.println("2 arg constructor");}

	public static void main(String[] args){
		Test5 obj1= new Test5();
		Test5 obj1= new Test5(10);
		Test5 obj1= new Test5(10, 20);}
}
*/
/*
// Example ---1

class Test5
{
	Test5(){
		this(10);					//calling 1 arg constructor
		System.out.println("0 arg constructor");}
	Test5(int a){
		this(10,20);	
		System.out.println("1 arg constructor");}
	Test5(int a, int b){
		System.out.println("2 arg constructor");}

	public static void main(String[] args){
		Test5 obj1= new Test5();}
}

*/

// Example ---2
class Test5
{
	Test5()
	{
		this(10);
		System.out.println("0 arg constructor");
																// call to this must be first statement in constructor
	}
	Test5(int a)
	{	
		this(10,20);
		System.out.println("1 arg constructor");
	}
	Test5(int a, int b)
	{
		System.out.println("2 arg constructor");
	}

	public static void main(String[] args){
		Test5 obj1= new Test5();}
}

/*
// Example ---3
class Test5
{
	Test5(){
		this(10);														// call to this must be first statement in constructor
		this(10,20);												// one constructor can call only one constructor at a time.
		System.out.println("0 arg constructor");
		}
	Test5(int a){	
		System.out.println("1 arg constructor");}
	Test5(int a, int b){
		System.out.println("2 arg constructor");}

	public static void main(String[] args){
		Test5 obj1= new Test5();}
}
*/