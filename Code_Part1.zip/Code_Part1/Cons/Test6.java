/* object creation approaches
1. Named approach:
Test obj=new Test();
2. Nameless approach: No refernce variable
 new Test();  ---> maximum usage
 */
class Test6
{
	Test6(){
		System.out.println("0 arg constructor");}
	Test6(int a){
		System.out.println("1 arg constructor");}
	Test6(int a, int b){
		System.out.println("2 arg constructor");}

	public static void main(String[] args){
		//named approach
		Test5 obj1= new Test5();
		Test5 obj2= new Test5(10);
		Test5 obj3= new Test5(10, 20);
		//nameless approach
		 new Test5();
		 new Test5(10);
		 new Test5(10, 20);}
	
}