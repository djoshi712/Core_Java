class Test4{
	int eno;
	String ename;
	float esalary;
	void display(int eno, String ename, float esalary){
		System.out.println("emp name= " +eno);
		System.out.println("emp no= " +ename);
		System.out.println("emp salary= " +esalary);}
	public static void main(String[] args){
		Test4 obj1= new Test4();
		obj1.display(121, "arjun", 50000.50f);
		Test4 obj2= new Test4();
		obj2.display(122, "meera", 60000.50f);}}