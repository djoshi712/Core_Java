
/* Advantage of constructor:
1) Constructors logics are executed when we create the objects, if we want to execute a particular task during object creation then we use constructors.
*/
class Test3
{
	// Test3()
	// {
	// 	System.out.println("constructors logic here");
	// }
	public static void main(String[] args) 
	{
	 Test3 obj= new Test3();	
	}
}
