//Copy Constructor in Java
//Like C++, Java also supports copy constructor. But, unlike C++, Java doesn�t create a default copy constructor if you don�t write your own.

class A { 
     int a, b;     
     A(int a, int b) {
        this.a = a;
        this.b = b;
    }   

	 A(A c) {
        System.out.println("Copy constructor called");
        a = c.a;
        b = c.b; }
}
 class Main {
    public static void main(String[] args) {
        A c1 = new A(10, 15);
		System.out.println(c1);
        A c2 = new A(c1);    
        A c3 = c2;   
 
        System.out.println(c2); // toString() of c2 is called here
    }
}
