import pack1.D;
class Deepa
{	
public static void main(String[] args)
{
	D obj= new D();	
	System.out.println(obj.x);
	
}
 
}