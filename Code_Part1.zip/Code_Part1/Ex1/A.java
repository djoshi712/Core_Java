class A
{
public static void main(string[] args){
boolean x= false;
    boolean y= false;
     if(x!=y!=x){
         System.out.println(�true�);}
     else     { System.out.println(�false�); }}
}