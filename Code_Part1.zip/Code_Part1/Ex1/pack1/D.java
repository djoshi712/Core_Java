package pack1;
public class D
{
int x=10;
int y=5;

}
