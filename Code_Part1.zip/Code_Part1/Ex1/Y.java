public class Shape{
public abstract void draw();
}
class Circle extends Shape{
public void draw() { System.out.println(�in draw��); }
}


