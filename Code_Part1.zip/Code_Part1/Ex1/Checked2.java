//Reading the file cust.txt present in F: and displaying its content on the screen. using 
//try catch
import java.io.*;
class Checked2 {  
   public static void main(String args[]) throws FileNotFoundException
   {
	FileInputStream obj= null;
		try {
		
		obj = new FileInputStream("F:/cust.txt");}
catch(NullPointerException e)
{
e.getMessage();}
	
	int k; 
	try
	{	
	    while(( k = obj.read() ) != -1) { 
				System.out.print((char)k);} 
			obj.close(); 
	}
	catch(IOException e)
	{
		System.out.print("Get Lost" +e);
	}	
   }
}