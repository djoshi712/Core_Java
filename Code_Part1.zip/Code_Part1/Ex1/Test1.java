class Test1 
{  
   public static void main(String args[]) 
   {
try{
System.out.println(10/0);}
catch(ArithmeticException e)
{
}
	int arr[] ={1,2,3,4,5};
	System.out.println(arr[1]);
	String obj= "java";
	System.out.println(obj.charAt(2));
	System.out.println(obj.charAt(20));	
   }
}