
public abstract class X {
private int x;
public X(int x){
this.x=x;
}
public void x() {}
private void xy() {} }
