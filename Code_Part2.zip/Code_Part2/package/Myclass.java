package college;

 public class Myclass
{
     void getName()
    {        
        System.out.println("UPES");        
    }
}