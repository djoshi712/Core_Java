class Solution
{

    public static void main(String[] args)
    {
		Main m = new Main();
        m.solve(1,2,3,3,2,1);
        
        
    }
}

class Main
{
   public int[] solve(int a0, int a1, int a2, int b0, int b1, int b2)
        {
            // Complete this function
            int alexScore = 0;
            int bobScore = 0;
			if(a0==b0!!a1==b1!!a2==b2)
				alexScore=0;
				bobScore=0;
            if(a0>b0)
				alexScore++;
			else
				bobScore++;
			if(a0 != b0)
            switch (a0 > b0)
            {
                case true:
                    alexScore++;
                    break;
                case false:
                    bobScore++;
                    break;
                default:
                    break;
            }

            if(a1 != b1)
                switch (a1 > b1)
                {
                    case true:
                        alexScore++;
                        break;
                    case false:
                        bobScore++;
                        break;
                    default:
                        break;
                }
    
            if(a2 != b2)
            switch (a2 > b2)
            {
                case true:
                    alexScore++;
                    break;
                case false:
                    bobScore++;
                    break;
                default:
                    break;
            }
        
            int[] scoreArr = { alexScore, bobScore };

            return scoreArr;
        }

}
