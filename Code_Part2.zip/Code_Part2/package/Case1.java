import java.lang.invoke.*;
class Case1
{
public static void main(String[] args)
{
 VerifyError obj= new VerifyError();
 System.out.println(obj.getClass().getName());
 MethodType obj1= new MethodType();
 System.out.println(obj1.getClass().getName());
 }
 }

