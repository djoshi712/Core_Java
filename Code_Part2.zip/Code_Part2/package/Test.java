package com.tcs.bank.loans;
class Test
{
	public static void main(String[] args)
	{
	System.out.println("Hi");
	}
}
class A 
{
}
interface Inter 
{
}

