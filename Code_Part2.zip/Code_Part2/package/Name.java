package bank;  
import college.Myclass; 
  
class Name{  
  public static void main(String args[]){  
	Myclass obj= new Myclass();
	obj.getName();
 
   
  }  
}  

