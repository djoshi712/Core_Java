package in.ac.upes.stu;
public class Student
{
	private int age;
	private String name;
	private float balance;

	Student(int age, String name, float balance)
	{
		this.age= age;
		this.name= name;
		this.balance= balance;
	}
	public int getAge()
	{
		return age;
	}
	public int getName()
	{
		return name;
	}
	public int getBalance()
	{
		return balance;
	}
	public void getAge(int a)
	{
		this.age=a;
	}
	public int getName(String n)
	{
		this.name= n;
	}
	public int setBalance(float ded)
	{
		this.balance = this.balance - ded;
	}
	float calculateCGPA(float maths, float c, float java)
	{
		float total;
		total= maths+c+java;
		return total;
	}
	public String toString()
	{
		return "balance is "+balance+"age is "+age+" name is  "+name;
	}
	
}
class Clubs
{
	public static void main(String[] args)
	{
		Student s1= new Student(21, "Shyam", 0);
		Student s2= new Student(20, "Ram", 100);
		if(Math.round(s1.calculateCGPA()) > 8 && Math.round(s2.getBalance())==0)
		{
			System.out.println("Welcome to the club");
		}
		else
		{
			System.out.println("sorry! can;t be a part of club");
		}
	}
}
interface Projects
{
	int duration= 3;
	int noMentor= 1;
	float calculateMidGrade();
	float calculateEndGrade();
	float calculateMentorMarks();
	float calculatePanelMarks();
}

class MinorProject extends Projects
{
	float calculateMidGrade(){}
	float calculateEndGrade(){}
	float calculateMentorMarks(){}
	float calculatePanelMarks(){}
}

class MajorProject extends Projects
{
	float calculateMidGrade(){}
	float calculateEndGrade(){}
	float calculateMentorMarks(){}
	float calculatePanelMarks(){}	
}

