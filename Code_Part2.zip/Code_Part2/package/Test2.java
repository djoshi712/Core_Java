package in.ac.upes.sre;
import in.ac.upes.stu.Student; 
//import com.ibm.info.*;
public class Account
{
	public static void main(String[] args)
	{
		in.ac.upes.stu.Student obj=new in.ac.upes.stu.Student(21, "Ram", 10000.0);
		obj.getBalance();
		obj.setBalance(5000);
		System.out.println(obj);
		//obj.calculateCGPA
		
	}
}
