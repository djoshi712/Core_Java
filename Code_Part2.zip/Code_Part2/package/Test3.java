

import java.util.*;

class Test3
{
	public static void main(String[] args)
	{
		Date d= new Date();
		System.out.println(d.getClass().getName());
	}
}
