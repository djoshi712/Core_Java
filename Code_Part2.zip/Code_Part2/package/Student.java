package in.ac.upes.stu;
public class Student
{
	private int age;
	private String name;
	private float balance;

	public Student(int age, String name, float balance)
	{
		this.age= age;
		this.name= name;
		this.balance= balance;
	}
	public int getAge()
	{
		return age;
	}
	public String getName()
	{
		return name;
	}
	public float getBalance()
	{
		return balance;
	}
	public void getAge(int a)
	{
		this.age=a;
	}
	public void getName(String n)
	{
		this.name= n;
	}
	protected void setBalance(float ded)
	{
		this.balance = this.balance - ded;
	}
	float calculateCGPA(float maths, float c, float java)
	{
		float total;
		total= (maths+c+java)/3.0f;
		return total;
	}
	public String toString()
	{
		return "balance is "+balance+"age is "+age+" name is  "+name;
	}
	
}
class Clubs
{
	public static void main(String[] args)
	{
		Student s1= new Student(21, "Shyam", 0);
		Student s2= new Student(20, "Ram", 100);
        float cgpa= s1.calculateCGPA(90, 92.5f, 91);
        float bal= s1.getBalance();
        System.out.println(cgpa);
        System.out.println(bal);
		if(Math.round(cgpa) > 8 && Math.round(bal)==0)
		{
			System.out.println("Welcome to the club");
		}
		else
		{
			System.out.println("sorry! can;t be a part of club");
		}
	}
}
interface Projects
{
	int duration= 3;
	int noMentor= 1;
	void calculateMidGrade();
	void calculateEndGrade();
	void calculateMentorMarks();
	void calculatePanelMarks();
}

class MinorProject implements Projects
{
	public void calculateMidGrade(){}
	public  void calculateEndGrade(){}
	public  void calculateMentorMarks(){}
	public  void calculatePanelMarks(){}
}

class MajorProject implements Projects
{
	public void calculateMidGrade(){}
	public  void calculateEndGrade(){}
	public  void calculateMentorMarks(){}
	public  void calculatePanelMarks(){}	
}

