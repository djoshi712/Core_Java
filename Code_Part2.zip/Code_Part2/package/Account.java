package in.ac.upes.sre;
import in.ac.upes.stu.Student; 
//import com.ibm.info.*;
public class Account
{
	public static void main(String[] args)
	{
		Student obj=new Student(21, "Ram", 10000.0f);
		obj.getBalance();
		//obj.setBalance(5000);
		System.out.println(obj);
		//obj.calculateCGPA(23, 34, 45);
		
	}
}

class Test extends Student
{
	public Test(int age, String name, float balance)
	{
		super(age, name, balance);
	}
	public static void main(String[] args)
	{
		Test obj=new Test(21, "Ram", 10000.0f);
		obj.getBalance();
		obj.setBalance(5000);
        System.out.println(obj);
	}
}
