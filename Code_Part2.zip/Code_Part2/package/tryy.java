import java.util.*;
import java.lang.*;
import java.io.*;

class Codechef{
public static void main (String[] args)
{
Scanner sc = new Scanner(System.in);

int T=0,n=0,k;

T = sc.nextInt();

for(int i=0;i<T;i++)
{
	n = sc.nextInt();
	for(int j=0;j<n;j++){
		       String input = sc.nextLine();

       String input1 = sc.nextLine();
        String value[] = input1.split(" ");
System.out.println(value[1]);

}}}}

