//set size and location
//setSize(width, height), setLocation(left_pixel,top_pixel), 
//setBounds(left_pixel,right_pixel,width,height)>>both together
import javax.swing.*;
class Test1
{
	public static void main(String[] args)
	{
		JFrame f= new JFrame();
		f.setVisible(true); 
		//f.setSize(700,500);	
		//f.setLocation(200,200);
		f.setBounds(100,100,1000,700);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	} 
}