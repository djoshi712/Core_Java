//set icon using setIconImage()
import javax.swing.*;
//setIconImage(image), setTitle("String")
//setBackground
class Test2
{
	public static void main(String[] args)
	{
		JFrame frame= new JFrame();
		frame.setVisible(true); 
		//frame.setSize(700,500);	
		//frame.setLocation(200,200);
		frame.setBounds(100,100,1000,700);
		JPanel content = new JPanel();
        content.setLayout(...);
        content.setBorder(BorderFactory.createEmptyBorder(11,11,11,11));
		frame.setTitle("Hey! How u doing!!!");
		frame.setBackground
		ImageIcon i= new ImageIcon("download.png");
		frame.setIconImage(i.getImage()); //convert imageIcon to image
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	} 
}