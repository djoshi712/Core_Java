//JFrame: setVisible, setDefaultCloseOperation
import javax.swing.*;
class Test
{
	public static void main(String[] args)
	{
		JFrame frame= new JFrame();
		frame.setVisible(true); 
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
