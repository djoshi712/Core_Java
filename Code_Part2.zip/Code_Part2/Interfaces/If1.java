Interface If1	
{
	void m1();  //public abstract 
	void m2();
	void m3(); 
}
class Test implements If1	//Implemtation part goes here
{
	void m1()
	{System.out.println("m1 method");}
	void m2()
	{System.out.println("m2 method");}
	void m3()
	{System.out.println("m3 method");}
	public static void main(String[] args) 
	{
		Test t= new Test();
		t.m1();
		t.m2();
		t.m3();
	}
}
