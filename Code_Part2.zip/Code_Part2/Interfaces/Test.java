interface If1	
{
	void m1();  //public abstract 
	void m2();
	void m3(); 
}
class Test implements If1	//Implemtation part goes here
{
	public void m1()
	{System.out.println("m1 method");}
	public void m2()
	{System.out.println("m2 method");}
	public void m3()
	{System.out.println("m3 method");}
	public static void main(String[] args) 
	{
		Test obj= new Test();
		obj.m1();
		obj.m2();
		obj.m3();
	}
}
