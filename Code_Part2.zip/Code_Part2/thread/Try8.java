class ThreadA
{
	public static void main(String arg[])
	{
		ThreadB b = new ThreadB();
		b.start();
		b.join();
		System.out.println(b.total);
	}		
}
class ThreadB extends Thread
{
int total = 0;
	public void run()
	{		
		System.out.println("Child Starting calculation");
			for(int i = 1; i<=100; i++)
			{
				total = total + i;
			}	
			;
			;
			;
			;
			;
	}
}