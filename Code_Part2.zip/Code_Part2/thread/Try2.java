class Counter1
{
static int c;

public synchronized void count(String name)
{
c=c+1;
System.out.println(name+".."+c);
}
}

class MyThread extends Thread
{
Counter1 d;
String name;

MyThread(Counter1 d,String name)
{
this.d = d;
this.name = name;
}

public void run()
{
d.count(name);
}
}

class Try2
{
public static void main(String arg[])
{
Counter1 d = new Counter1();
MyThread t1 = new MyThread(d,"A");
MyThread t2 = new MyThread(d,"B");
MyThread t3 = new MyThread(d,"C");
MyThread t4 = new MyThread(d,"D");
MyThread t5 = new MyThread(d,"E");
t1.start();
t2.start();
t3.start();
t4.start();
t5.start();
}
}