//Java program to illustrate the
// behaviour of notify() method

class Thread1 extends Thread {  
public void run()
    {
        synchronized(this)
        {
            System.out.println(Thread.currentThread().getName() + "...starts");
            try {
                wait();
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread().getName() + "...notified");
        }
    }
} 

class Thread2 extends Thread {
	
  Thread1 t1;
  Thread2(Thread1 t1)
		{
			this.t1=t1;
		}  
	public void run()
    {		
        synchronized(this.t1)
        {
            System.out.println(Thread.currentThread().getName() + "...starts");
			
            try {
                this.t1.wait();
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(Thread.currentThread().getName() + "...notified");
        }
    }
}

class Thread3 extends Thread {
  Thread1 t1;
  Thread3(Thread1 t1)
		{
			this.t1=t1;
		}   
public void run()
    {
        synchronized(this.t1)
        {
            System.out.println(Thread.currentThread().getName() + "...starts");
            this.t1.notify();
            System.out.println("Done providing notification");
        }
    }
}

 class MainClass {
public static void main(String[] args) throws InterruptedException
    {
 
      Thread1 t1 = new Thread1();
      Thread2 t2 = new Thread2(t1);
      Thread3 t3 = new Thread3(t1);
        
        t1.start();
        t2.start();
		Thread.sleep(100);
        t3.start();
    }
}