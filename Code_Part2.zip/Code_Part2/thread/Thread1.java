
class MyThread extends Thread
{
	public void run() 					//overriding run method of Thread class
	{
		for(int i=0;i<100;i++)
		{
			System.out.println("child thread");
		}
	}
}
class Thread1
{
	public static void main(String[] args)
{
		MyThread t=new MyThread();
		t.start();
		for(int i=0;i<100;i++)
		{
			System.out.println("main thread");
		}
	}
} */
 
//Overloading run method
 /* class Mythread extends Thread
{
	public void run() 					
	{
			System.out.println("o-arg run");		
	}
	public void run(int i) 					
	{
			System.out.println("1-arg run");
		
	}	
}
class Thread1
{
	public static void main(String[] args)
	{
		Mythread t= new Mythread();
		t.start(); 						
		for(int i=0;i<5;i++)
		{
			System.out.println("main thread");
		}
	}
} 
*/
//Do not override run method
/*
 class Mythread extends Thread
{
	
}
class Thread1
{
	public static void main(String[] args)
	{
		Mythread t= new Mythread();
		t.start(); 						
		for(int i=0;i<5;i++)
		{
			System.out.println("main thread");
		}
	}
} 
*/
//Overloading start meethod
/*
class Mythread extends Thread
{
	public void start() 					
	{
			System.out.println("start method");		
	}
	public void run() 					
	{
			System.out.println("run method");
		
	}	
}
class Thread1
{
	public static void main(String[] args)
	{
		Mythread t= new Mythread();
		t.start(); 						
		for(int i=0;i<5;i++)
		{
			System.out.println("main thread");
		}
	}
}
*/ 
//caling run method using super

class Mythread extends Thread
{
	public void start() 					
	{
		super.start();	//calling start method of Thread class
		System.out.println("start method");		
	}
	public void run() 					
	{
		System.out.println("run method");		
	}
}
class Thread1
{
	public static void main(String[] args)
	{
		Mythread t= new Mythread();		//main thread creates child thread
		t.start();						//call start method of Thread class
		for(int i=0;i<5;i++)
		{
			System.out.println("main thread");
		}
	}
}


