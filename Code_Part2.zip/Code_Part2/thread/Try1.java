class ThreadA extends Thread
{
int total = 0;

	public void run() 
		{
		synchronized(this)
		  {
			for(int i=0; i<100; i++)
			{
			total= total+i;
			}
			this.notify();	
		  }			
		}
}
class ThreadB extends Thread
{
public void run()
{
	ThreadA a= new ThreadA();
	synchronized(a)
	{
		try{
		a.wait();}
		catch(InterruptedException e)
		{}
		System.out.println(a.total);
	}
}
}

class Main
{
	public static void main(String arg[]) throws InterruptedException
	{
		ThreadA a= new ThreadA();
		ThreadB b= new ThreadB();
		a.start();
		b.start();
		a.join();
		b.join();
	}	
}
