class Display
{
	public void wish(String name)
	{
		for(int i=0;i<10;i++)
		{
			System.out.print("Hello:");
			try
			{
				Thread.sleep(2000);
			}
			catch(InterruptedException e)
			{
			}
			System.out.println(name);
		}
	}
}
class ThreadDemo extends Thread
{
	String name;
	Display d;
	ThreadDemo(String name, Display d)
	{
		this.name=name;
		this.d=d;
	}
	public void run()
	{
		d.wish(name);
	}
}

class Test2
{
	public static void main(String[] args)
	{
		Display d1= new Display();
		//Display d2= new Display();
		ThreadDemo t1=new ThreadDemo("Ram", d1);
		ThreadDemo t2=new ThreadDemo("Shyam", d1);
		t1.start();
		t2.start();
	}
}