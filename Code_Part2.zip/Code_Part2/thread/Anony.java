//Creating Anonymous inner class by extending Thread class
class Test
{
	public static void main(String[] args)
	{
		Thread t= new Thread()
		{
			public void run()
			{
				for (int i=0;i<5;i++)
				{
					System.out.println("child thread using inner class");
				}
			}
		};
		t.start();
		for(int i=0;i<5;i++)
		{
			System.out.println("main thread");
		}
	}
}
