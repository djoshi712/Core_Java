class AnonyThread2
{
	public static void main(String[] args)
	{
		Runnable r = new Runnable()
		{
			public void run()
			{
				System.out.println("Hi from child thread " + Thread.currentThread());
			}
		};
		Thread t= new Thread();
		t.start();
		
	System.out.println("Hi from main thread " + Thread.currentThread());
	}
}
		
		