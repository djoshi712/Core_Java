//yield method
 /*class Mythread extends Thread{
	public void run()
	{
		for(int i=0;i<40;i++)
		{		
			Thread.yield();		
			System.out.println("child thread");	
		}
	}}
class Yield{	
	public static void main(String[] args)
	{
		Mythread t= new Mythread();
		t.start();
		for(int i=0;i<40;i++)
		{
			System.out.println("main thread");	
		}
	}
} */



/*
class Mythread extends Thread
 {
	public void run() 
	{		
			for(int i=0;i<10;i++)
			{			
				System.out.println("child thread");
				try{
				Thread.sleep(2000);	
				}
				catch(InterruptedException e){}						
			}
	}
 } 
class Sleep
{	
	public static void main(String[] args) throws InterruptedException
	{
		Mythread t= new Mythread();
		t.start();
		t.join();
		for(int i=0;i<20;i++)
		{
			System.out.println("main thread");	
		}
	}	
} 
*/
 
import java.io.*;  
  
class ThreadJoin extends Thread  
{  
	public void run()  
	{  
		for (int j = 0; j < 2; j++)  
		{  
		try  
		{  
			Thread.sleep(1000);  
			System.out.println("The current thread name is: " + Thread.currentThread().getName());  
		}  
		catch(Exception e)  
		{  
			System.out.println("The exception has been caught: " + e);  
		}  
		System.out.println( j );  
		}  
}  
}  
  
class ThreadJoinExample  
{  
	public static void main (String argvs[])  
	{  
		ThreadJoin th1 = new ThreadJoin();  
		ThreadJoin th2 = new ThreadJoin();  
		ThreadJoin th3 = new ThreadJoin();  
		th1.start();  
		try  
		{  
			System.out.println("The current thread name is: "+ Thread.currentThread().getName());  
			th1.join();  
		}  
  
		// catch block for catching the raised exception  
		catch(Exception e)  
		{  
			System.out.println("The exception has been caught " + e);  
		}  
  
		// thread th2 starts  
		th2.start();  
		
		// starting the th3 thread after when the thread th2 has ended or died.  
		try  
		{  
		System.out.println("The current thread name is: " + Thread.currentThread().getName());  
		th2.join();  
		}  
  
		// catch block for catching the raised exception  
		catch(Exception e)  
		{  
		System.out.println("The exception has been caught " + e);  
		}  
		
		// thread th3 starts  
		th3.start();  
		}  
		}  
/*
 class Mythread extends Thread{
	static thread mt;
	public void run()
	{
		try{
			mt.join();
			for(int i=0;i<10;i++)
			{			
				System.out.println("child thread");
				Thread.yield();		
			}
		}
		catch(InterruptedException e){}
	}}
class Sleep{	
	public static void main(String[] args) throws InterruptedException
	{
		Sleep mt=Thread.currentThread();
		Mythread t= new Mythread();
		t.start();
		for(int i=0;i<10;i++)
		{
			System.out.println("main thread");	
			Thread.sleep(2000);
		}
	}}
 */