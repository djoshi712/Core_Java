/*class Display
{	
void displayN
{
	for(int i=10; i<=20; i++)
	System.out.println(i);
}
void displayC
{
	for(int i=65; i<=75; i++)
	System.out.println((char)i);
}
}
class Thread1Job implements Runnable
{
	Display d;
	ThreadJob(Display d){this.d=d;}	
	public void run() { 
	d.displayN(); }
}
class Thread2Job implements Runnable
{
	Display d;
	Thread2Job(Display d){this.d=d;}	
	public void run() { 
	d.displayC(); }
}

class SynBlock
{
Display d= new Display();
Thread1Job t1= new Thread1Job(d);
Thread2Job t2= new Thread2Job(d);
Thread t3= new Thread(d);
Thread t4= new Thread(d);
t3.start();
t4.start();
}
*/

class Display
{	
synchronized void  displayN()
{
	for(int i=10; i<=20; i++)
	System.out.print(i);
}
synchronized void displayC()
{
	for(int i=65; i<=75; i++)
	System.out.print((char)i); }
}
class Thread1Job extends Thread{
	Display d;
	Thread1Job(Display d){this.d=d;}	
	public void run() { d.displayN(); }
}
class Thread2Job extends Thread{
	Display d;
	Thread2Job(Display d){this.d=d;}	
	public void run() { d.displayC(); }
}
class SynBlock
{
public static void main(String[] args){
Display d= new Display();
Thread1Job t1= new Thread1Job(d);
Thread2Job t2= new Thread2Job(d);
t1.start();
t2.start();
}}