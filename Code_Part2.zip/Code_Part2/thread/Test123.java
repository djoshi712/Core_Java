class A
{
	public void wish(String name)
	{	
	synchronized(this)
		{
		
			for(int i=0;i<10;i++)
			{			
			System.out.print("Hi: ");
			try{
			Thread.sleep(2000);
			}
			catch(InterruptedException e)
			{
			}			
			System.out.println(name);
			}
		}
	}
}


class Thread1 extends Thread{
	
	A obj;
	String name;
	Thread1(A obj, String name)
	{
		this.obj=obj;
		this.name=name;
		
	}
		
	public void run()
	{
		
		obj.wish(name);
		
	}
}	

class Main
{
	public static void main(String[] args)
	{
		A obj= new A();
		Thread1 t1= new Thread1(obj, "Ram");
		Thread1 t2= new Thread1(obj, "Shyam");
		t1.start();
		t2.start();
	}
}


