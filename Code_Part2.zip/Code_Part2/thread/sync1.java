class Display
{
	public void wish(String name)
	{
		for(int i=0;i<10;i++)
		{
			System.out.print("Hello: ");
			try
			{
				Thread.sleep(2000);
			}
			catch(InterruptedException e)
			{
			}
			System.out.println(name);
		}
	}
}
class Test1
{
	public static void main(String[] args)
	{
		Display d= new Display();
		d.wish("Ram");
		d.wish("Shyam");
	}
}