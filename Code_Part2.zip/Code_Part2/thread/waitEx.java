//Java program to illustrate the
// behaviour of notify() method

class Thread1 extends Thread {
public void run()
    {
        synchronized(this)
        {
            System.out.println
            (Thread.currentThread().getName() + "...starts");
            try {
                this.wait();
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println
            (Thread.currentThread().getName() + "...notified");
        }
    }
} 

class Thread2 extends Thread {
    Thread1 t1;
    Thread2(Thread1 t1)
    {
        this.t1 = t1;
    }
	public void run()
    {
        synchronized(this.t1)
        {
            System.out.println
            (Thread.currentThread().getName() + "...starts");
 
            try {
                this.t1.wait();
            }
            catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println
            (Thread.currentThread().getName() + "...notified");
        }
    }
}

class Thread3 extends Thread {
    Thread1 t1;
    Thread3(Thread1 t1)
    {
        this.t1 = t1;
    }
public void run()
    {
        synchronized(this.t1)
        {
            System.out.println
            (Thread.currentThread().getName() + "...starts");
            this.t1.notify();
            
        }
    }
}

 class MainClass {
public static void main(String[] args) throws InterruptedException
    {
 
        Thread1 t1 = new Thread1();
        Thread2 t2 = new Thread2(t1);
        Thread3 t3 = new Thread3(t1);
        Thread a1 = new Thread(t1, "Thread-1");
        Thread a2 = new Thread(t2, "Thread-2");
        Thread a3 = new Thread(t3, "Thread-3");
        a1.start();
        a2.start();
        Thread.sleep(100);
        a3.start();
    }
}