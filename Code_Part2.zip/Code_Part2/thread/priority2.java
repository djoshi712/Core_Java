
class ThreadDemo implements Runnable
{
    public void run()
    {
        System.out.println("Inside run method");
    }

    public static void main(String[]args)
    {
        ThreadDemo t1 = new ThreadDemo();
        ThreadDemo t2 = new ThreadDemo();
        ThreadDemo t3 = new ThreadDemo();
		Thread t4= new Thread(t1);
		Thread t5= new Thread(t2);		
		Thread t6= new Thread(t3);
		
		
        System.out.println("t1 thread priority : " +
                              t4.getPriority()); // Default 5
        System.out.println("t2 thread priority : " +
                              t5.getPriority()); // Default 5
        System.out.println("t3 thread priority : " +
                              t6.getPriority()); // Default 5

        t4.setPriority(2);
        t5.setPriority(5);
        t6.setPriority(8);

        // t3.setPriority(21); will throw IllegalArgumentException
        System.out.println("t1 thread priority : " +
                              t4.getPriority());  //2
        System.out.println("t2 thread priority : " +
                              t5.getPriority()); //5
        System.out.println("t3 thread priority : " +
                              t6.getPriority());//8

        // Main thread
        System.out.print(Thread.currentThread().getName());
        System.out.println("Main thread priority : "
                       + Thread.currentThread().getPriority());

        // Main thread priority is set to 10
        Thread.currentThread().setPriority(10);
        System.out.println("Main thread priority : "
                       + Thread.currentThread().getPriority());
    }
}