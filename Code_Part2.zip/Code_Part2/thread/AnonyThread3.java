class AnonyThread3
{
	public static void main(String[] args)
	{
		Thread t= new Thread (new Runnable()
		{
			public void run()
			{
				System.out.println("Hi from child thread " + Thread.currentThread());
			}
		});
		t.start();
		
	System.out.println("Hi from main thread " + Thread.currentThread());
	}
}