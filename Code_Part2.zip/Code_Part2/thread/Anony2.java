//creating Anonymous inner class by implementing Runnable interface
class Test
{
	public static void main(String[] args)
	{		
		Runnable r= new Runnable() 
		{
			public void run()
			{
				for (int i=0;i<5;i++)
				{
					System.out.println("child thread using inner class");
				}
			}
		};
		Thread t= new Thread(r);
		t.start();
		for(int i=0;i<5;i++)
		{
			System.out.println("main thread");
		}
	}
}

