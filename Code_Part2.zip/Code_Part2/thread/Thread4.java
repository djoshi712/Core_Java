
class Mythread extends Thread
{
    public void run()
    {
	System.out.println ("Thread "+ Thread.currentThread().getName()+"is running");
	}
}
class Thread4
{
    public static void main(String[] args)
    {
        for (int i=0; i<5; i++)
        {
            Mythread t = new Mythread();
            t.start();
        }
    }
}