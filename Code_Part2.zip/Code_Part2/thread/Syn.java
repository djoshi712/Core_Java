//Synchronization program 
/*
import java.util.Scanner;
class Reservation
{
	private int seatAvailability;
	public Reservation(int seatAvailability)
	{
		this.seatAvailability=seatAvailability;
	}	
	public  boolean isTicketAvailable(int noOfSeats)
	{
		if(seatAvailability>=noOfSeats)
			return true;
		else
			return false;
	}
	public synchronized void bookTicket(int noOfSeats, String name)
	{	
		seatAvailability=seatAvailability-noOfSeats;
		System.out.println("no of tickets booked for " +name+ " "+noOfSeats);
		System.out.println("no of seats available are " +seatAvailability);
	}
}

class MyThread extends Thread
{
	private Reservation r;
	private String name;
	MyThread(Reservation r, String name)
	{
		this.r=r;
		this.name=name;
	}
	public void run()
	{
		Scanner s= new Scanner(System.in);
		System.out.println(name+",Enter no of tickets to be booked");		
		int n=s.nextInt();		
		if(r.isTicketAvailable(n))
		{
			//System.out.println(name);
			r.bookTicket(n, name);
		}
		else	
		System.out.println(name+ " Sorry! seats are not available");
	}
}
class Syn
{
	public static void main(String[] args)
		{	
			Reservation r= new Reservation(10);	
			MyThread t1 = new MyThread(r, "Ram");
			MyThread t2 = new MyThread(r,"Sita");
			t1.start();
			t2.start();
		}
}
*/



//if a thread wants to execute a synchronized method on this(Reservation)
//, it has to acquire lock on this object
//acquiring and releasing the lock will be done automatically by JVM.
//if a thread executing synchronized method on the given object, the 
//remaining threads are not allowed to execute any synchronized method 
//simultaneously on the same object, but remaining threads are allowed to 
//execute non-synchronized methods simultaneously
//every object has two areas, synchronized and non-synchronized area.

import java.util.Scanner;
class Reservation
{
	private int seatAvailability;
	public Reservation(int seatAvailability)
	{
		this.seatAvailability=seatAvailability;
	}	
	
	public void bookTicket(int noOfSeats, String name)
	{	
		;;;;;;;;;;;;;;;;;;;;;;;;;;;;
		synchronized(this)
		{
			
			if(seatAvailability>=noOfSeats)
			{
				seatAvailability=seatAvailability-noOfSeats;
				System.out.println("no of tickets booked for " +name+ " are "+noOfSeats);
				System.out.println("no of seats available are "+seatAvailability);
			}
			else
			{
				System.out.println("seats not available");
			}
		}
	
	
	}
}


class Client extends Thread
{
	private Reservation r;
	private String name;

	Client(Reservation r, String name)
	{
		this.r=r;
		this.name=name;
	}
	public void run()
	{
		Scanner s= new Scanner(System.in);
		System.out.println(name+",Enter no of tickets to be booked");		
		int n=s.nextInt();		
		r.bookTicket(n, name);
	}
}

class Syn
{
	public static void main(String[] args)
		{	
			Reservation r= new Reservation(10);
			Thread t1= new Thread(new Client(r,"Jai"));
			Thread t2= new Thread(new Client(r,"Veeru"));
			t1.start();
			t2.start();
		}
}


