class Display
{
	public void displayn()
	{
		for(int i=0;i<5;i++)
		{
			try
			{	
			Thread.sleep(1000);
			}
			catch(InterruptedException e)
			{
			}
			System.out.println(i);
		}
	}
	public void displayc() 
	{
		for(int i=65;i<70;i++)
		{
			try
			{	
			Thread.sleep(1000);
			}
			catch(InterruptedException e)
			{
			}
			System.out.println((char)i);
		}
	}
	
}

class Thread1 extends Thread
{
	Display d;
	Thread1(Display d)
	{
		this.d=d;
	}
	public void run()
	{
		d.displayn();
	}
}

class Thread2 extends Thread
{
	Display d;
	Thread2(Display d)
	{
		this.d=d;
	}
	public void run()
	{
		d.displayc();
	}
}

class Main
{
	public static void main(String[] args)
	{
		Thread1 t1= new Thread1(new Display());
		Thread2 t2= new Thread2(new Display());
		t1.start();
		t2.start();
	}
}
		
	