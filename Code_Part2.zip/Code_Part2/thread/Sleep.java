class Sleep
{
	public static void main(String[] args) throws InterruptedException
	{
		for(int i=0;i<10;i++)
		{
			System.out.println("main thread");
			Thread.sleep(1000);
		}
	}
}

class Mythread extends Thread 
{		
	public void run() 
	{
		try{ 
			for(int i=0;i<10;i++){
			System.out.println("I want to sleep");
			Thread.sleep(2000);}
			}
			catch(InterruptedException e){
			System.out.println("I got interrupted");}
			
	}
}
class Sleep
{
	public static void main(String[] args) 
	{
		Mythread t= new Mythread();
		t.start();
		//t.interrupt();
		System.out.println("main thread");
	}
}

