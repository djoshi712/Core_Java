class ThreadA {        
    public static void main(String[] agrs) throws InterruptedException
	{
        ThreadB t = new ThreadB();
        t.start(); 
		System.out.println("Hi");
        System.out.println(t.count);
    }
}

class ThreadB extends Thread {
    int count = 0;
    public void run() { 
        for(int i = 0; i < 10; i++) 
		{
            count = count + i;
        }
	}
    
}