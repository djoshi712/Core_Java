//Defining a thread using Runnable interface
class A implements Runnable 
{  
    public void run() 
	{
    System.out.println(Thread.currentThread().getName()+" is running ");
    }
}

class B implements Runnable 
{  
    public void run() 
	{
    System.out.println(Thread.currentThread().getId()+" is running ");
    }
}
public class Test1
{
    public static void main(String[] args) 
	{
    Thread t1= new Thread(new A());
	Thread t2= new Thread(new B());
	t1.start();
	t2.start();	
    }
	
}

