interface Runnable
{
abstract public void run(){}
}
class A extends Thread implements Runnable
{	Runnable obj;
    A(Runnable obj){this.obj= obj;} 
    public void run() 
	{
    System.out.println("Printing A");
    }
}
class B implements Runnable {
    public void run() 
	{
    System.out.println("Printing B");
    }
}
public class Test 
{
    public static void main(String[] args) 
	{
		//new Thread(new B()).start();
		new A(new B()).start();
		System.out.println("Printing main");
    }
}