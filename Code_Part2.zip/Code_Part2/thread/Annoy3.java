//Anonymous inner class that defined inside arguments 

class Test
{
	public static void main(String[] args)
	{				
		Thread t= new Thread(
		new Runnable()
		{
			public void run()
			{
				for (int i=0;i<5;i++)
				{
					System.out.println("child thread using inner class");
				}
			}
		}
		);
		t.start();
		
		*/
		new Thread(new Runnable()
		{
			public void run()
			{
				for (int i=0;i<5;i++)
				{
					System.out.println("child thread using inner class");
				}
			}
		}).start();
		for(int i=0;i<5;i++)
		{
			System.out.println("main thread");
		}
	}
}

