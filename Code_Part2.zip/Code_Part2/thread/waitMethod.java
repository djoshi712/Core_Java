//wait, notify >>methods:	
//this thread is responsible to print count value
/*
class ThreadA
{
	public static void main(String[] agrs ) 
	{
		ThreadB t=new ThreadB();
		t.start(); 
		System.out.println("hi");		
		System.out.println(t.count);
	}
}
//this thread is responsible to update count value
class ThreadB extends  Thread
{
	int count=0;
	public void run()
	{	
		for(int i=1; i<=100; i++) 						
		{
			count=count+i;
		}
	}
}*/
//ThreadA waits for predefined amount of time for ThreadB to finish its execution
//if ThreadB finishes early, then ThreadA waits unnecessarly, wasting utilization
/*
class ThreadA
{
	public static void main(String[] agrs ) throws InterruptedException
	{
		ThreadB t=new ThreadB();
		t.start();
		Thread.sleep(0, 1);
		System.out.println(t.count);
	}
}
class ThreadB extends  Thread
{
	int count=0;
	public void run()
	{	
		for(int i=1; i<=100; i++) 						
		{
			count=count+i; 
		}
	}
}*/

//join>>  performance decreases
/*class ThreadA
{
	public static void main(String[] agrs ) throws InterruptedException
	{
		ThreadB t=new ThreadB();
		t.start();
		t.join(1000);
		System.out.println(t.count);
	}
}
class ThreadB extends  Thread
{
	int count=0;
	public void run()
	{	
		for(int i=1; i<=100; i++) 						
		{
			count=count+i;
		}
		;
		;
		;
		;
		;
		;
		;
		
	}
}*/

//using wait method>>Recommended approach
class ThreadA
{
	public static void main(String[] agrs ) throws InterruptedException
	{
		ThreadB t=new ThreadB();
		t.start();
		synchronized(t)
		{
			t.wait(1000);
		}
		System.out.println(t.count);
	}
}
class ThreadB extends  Thread
{
	int count=0;
	public void run()
	{	
		synchronized(this)
		{
			for(int i=1; i<=10000; i++) 						
			{
				count=count+i;
			}
			this.notify();
		}
	}
}

/*class ThreadA
{
	public static void main(String[] agrs ) throws InterruptedException
	{
		ThreadB t=new ThreadB();
		t.start();
		synchronized(t)
		{
		System.out.println("main thread going to wait now");
		t.wait();
		System.out.println("main thread gets notification");
		System.out.println(t.count);
		}
	}
}
/*class ThreadB extends  Thread
{
	int count=0;
	public void run()
	{	
	synchronized(this)
	{
		System.out.println("child thread starts calculation");
		for(int i=1; i<=1000; i++) 						
		{
			count=count+i;
		}
		System.out.println("child thread gives notification");
		this.notify();
	}
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
		;
	}
}*/

