//getting and setting name of a thread
//getting and setting priority of a thread

/* class Mythread extends Thread
{
	public void run() 					//overriding run method of Thread class
	{
		for(int i=0;i<5;i++)
		{
			System.out.println("child thread");
		}
	}
}
class Thread3
{
	public static void main(String[] args)
	{
		System.out.println(Thread.currentThread().getName());
		Mythread t= new Mythread();
		System.out.println(t.getName());	
		Thread.currentThread().setName("java");
		System.out.println(Thread.currentThread().getName());		
		t.start(); 
		for(int i=0;i<5;i++)
		{
			System.out.println("main thread");
		}
	}
}  */

  class Mythread extends Thread
{
	public void run() 					//overriding run method of Thread class
	{
		for(int i=0;i<5;i++)
		{
			System.out.println("child thread");
		}
	}
}
 class Thread3
{
	public static void main(String[] args)
	{
		//System.out.println(Thread.currentThread().getPriority());
		Mythread t= new Mythread();
		System.out.println(t.getPriority());	
		t.setPriority(9);
		System.out.println(t.getPriority());		
		t.start(); 
		for(int i=0;i<5;i++)
		{
			System.out.println("main thread");
		}
	}
} 
 