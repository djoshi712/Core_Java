//join method
/*
class Mythread extends Thread{
	public void run() 
	{
		for(int i=0;i<10;i++)
		{
			System.out.println("child thread");				
		}
		
	}}
class Join {
	public static void main(String[] args) throws InterruptedException
	{
		Mythread t= new Mythread();
		t.start();
		try{
		Thread.sleep(1000);}
		catch(InterruptedException e)
		{}
		
		for(int i=0;i<10;i++)
		{
			System.out.println("main thread");
		}
	}}
	*/
//Example:2 >>waiting for main thread to finish

class Mythread extends Thread{	
	public void run(){
		try{ Join.a.join();}    		
		catch(InterruptedException e) {}
		for(int i=0;i<10;i++){					
		System.out.println("child thread");}
	}}
class Join{
	static Thread a;
	public static void main(String[] args) throws InterruptedException
	{
		a=Thread.currentThread();
		Mythread t= new Mythread();
		t.start(); 
		for(int i=0;i<5;i++){
			System.out.println("main thread");
			Thread.sleep(1000);}
	}}
	
//Example:3
/*class Join{
	public static void main(String[] args) throws InterruptedException
	{
		Thread.currentThread().join();	
		for(int i=0;i<10;i++)
		{
			System.out.println("main thread");
		}
	}
}*/