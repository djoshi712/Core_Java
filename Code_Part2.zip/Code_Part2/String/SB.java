/*   class SB
{
	public static void main(String ar[])
	{
		StringBuffer s= new StringBuffer();
		System.out.println(s.capacity()); //16
		s.append("abcdefghijklmnop");
		System.out.println(s.capacity()); //16
		s.append("q");
		System.out.println(s.capacity()); //34
		s.append("qsddsfjkdkfhdkjfhjsdhjkhskfhdjhfjshdjsh");
		System.out.println(s.capacity()); // 70
		s.append("i");
		System.out.println(s.capacity()); //70
	}
}   */

 class SB
{
	public static void main(String ar[])
	{
		
		StringBuffer s1= new StringBuffer(1000); //1st constructor
		System.out.println(s1.capacity()); 
		StringBuffer s2= new StringBuffer("Ram"); //create equivalent stringbuffer object for string
		System.out.println(s2.capacity());	//19
		//System.out.println(s2.charAt(5)); 
		s2.setCharAt(2,'o'); //
		System.out.println(s2);
		s2.append(10);
		System.out.println(s2);
		s2.insert(1,"abc"); //overloaded method
		System.out.println(s2);
		s2.delete(2,5); //n-1
		System.out.println(s2);
	}
} 

 /* class SB
{
	public static void main(String ar[])
	{
		StringBuffer s1= new StringBuffer("jhsdgjsghjasd"); //1st constructor
		System.out.println(s1.capacity());
		s1.setLength(5);		
		System.out.println(s1.capacity());
		System.out.println(s1);
		s1.ensureCapacity(1000); //assume we created an empty sb, default initial
		//capacity is 16 here, then we came to know that we need 1000 
		//characters need to be added. Increase capacity dynamically using 
		//ensureCapacity
		System.out.println(s1.capacity());
		//trimToSize: improve memory utilization (extra allocated free memory is deallocated)
		StringBuffer s2= new StringBuffer(1000); 
		s2.append("abc");
		System.out.println(s2.capacity());
		s2.trimToSize();
		System.out.println(s2.capacity());
		
	}
}  */