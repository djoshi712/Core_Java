
#include<stdio.h>
int main()
{
    int n, fact=1;
    printf("Enter a no.");
    scanf("%d", &n);
    int x =facto(n,fact);
    printf("Factorial of %d is %d", n, x);
}

int facto(int n, int fact)
{
    if(n==1)
    return fact;
    fact = fact * n;
    facto(n,fact);
}
