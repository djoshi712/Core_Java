//
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Collections;
class Intro3
{
	public static void main(String[] args)
	{
		/* /* Collection<Integer> values= new ArrayList<Integer>();
		values.add(2);
		values.add(3);
		values.add(5);
		/*add a new element, now i want to add this after 3, but in Collection interface
		we do not have anything to specify the index number. We have other interface List in
		which provides index number 
		values.add(4); */ 
		
		List<Integer> values= new ArrayList<Integer>();
		values.add(2);
		values.add(3);
		values.add(5);
		values.add(2, 4);
		
		//adding random values to the list
		Random r= new Random();
		
		for(int i=0; i<100; i++)
		{
			values.add(r.nextInt(100));
		}

sort(List<T> list)
Sorts the specified list into ascending order, according to the natural
ordering of its elements.
static <T> void	sort(List<T> list, Comparator<? super T> c)
Sorts the specified list according to the order induced by the specified 
comparator. 

sort method is not available in Collection interface
java.util.Collections.sort() method is present in java.util.Collections class. It is used to sort the elements present in the specified list of Collection in ascending order.
It works similar to java.util.Arrays.sort() method but it is better then as
it can sort the elements of Array as well as linked list, queue and many 
more present in it.
Collections.sort method is sorting the elements of ArrayList in ascending 
order.Collections.sort(al, Collections.reverseOrder());
		
		Collections.sort(values);
		for(Integer i: values)
		{
			System.out.println(i);
		}
		
	}
}