
 class Try1
{
	public static void main(String ar[])
	{
		String name=null;
		System.out.println(name.hashCode());
	}
	}
		