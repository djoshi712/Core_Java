class outer
{
	 class inner
	{
		void m1(int x,int y)
		{
			int z=x+y;
			System.out.println(z);
		}
	}
	public static void main(String ar[])
	{
		outer out1=new outer();
		outer.inner inn=out1.new inner();
		inn.m1(10,20);
	}
}
class test21 extends outer
{
	public static void main(String ar[])
	{
		outer out1=new outer();
		outer.inner inn=out1.new inner();
		inn.m1(10,20);
		
	}
}
	