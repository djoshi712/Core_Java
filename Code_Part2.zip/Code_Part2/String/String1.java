//case-2

//== operator
/*
 class String1
{
	public static void main(String[] args)
	{
		String s1= "java";
		String s2= "subject";
		String s3= "java";
		String s4= new String("java");
		String s5= new String("subject");
		String s6= new String("java");
		System.out.println(s1==s2);
		System.out.println(s1==s3);
		System.out.println(s2==s3);
		System.out.println(s4==s5);
		System.out.println(s4==s6);
		System.out.println(s5==s6);
	}
}  
//case-3
*/
/*
  class String1
{
	public static void main(String[] args)
	{
		String s1= "java";
		s1.concat("subject");
		System.out.println(s1);

		StringBuffer s2= new StringBuffer("java");
		s2.append("subject");
		System.out.println(s2);
	}
} */ 
//case-4

   class Student extends Object
{
		int eid;
		String ename;
		Student(int eid, String ename)
		{
			this.eid= eid;
			this.ename=ename;
		}
		public static void main(String[] args)
		{
			Student s= new Student(10, "Ram");
			System.out.println(s.toString());
			String s1= new String("java");
			System.out.println(s1.toString());
			// StringBuffer s2= new StringBuffer("PHP");
			// System.out.println(s2);
		}
}   

/* class String1
{
		int eid;
		String ename;
		String1(int eid, String ename)
		{
		this.eid= eid;
		this.ename=ename;
		}
		public String toString()
		{
		return "ename="+ename+" eid="+eid;
		}
		public static void main(String[] args)
		{
		String1 obj= new String1(10, "Ram");
		System.out.println(obj);
		}
} */
/*
class String1
{
	public static void main(String[] args)
	{
		String s1= "java";
		System.out.println(s1);
		System.out.println(s1.toString());
		StringBuffer s2= new StringBuffer("PHP");
		System.out.println(s2);
		System.out.println(s2.toString());
	}
}*/

//case-5
/*class String1
{	
		String1(String s){}
		public static void main(String[] args)
		{
		String1 obj1= new String1("java");
		String1 obj2= new String1("java");
		String1 obj3= obj1;
		System.out.println(obj1.equals(obj2)); 
		System.out.println(obj1.equals(obj3)); 
		
		String s1= "java";
		String s2= "java";
		System.out.println(s1.equals(s2));
		
		StringBuffer sb1= new StringBuffer("java");
		StringBuffer sb2= new StringBuffer("java");
		System.out.println(sb1.equals(sb2));
		
	}
}*/