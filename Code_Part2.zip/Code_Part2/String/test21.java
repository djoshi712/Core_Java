class test21 extends outer
{
	public static void main(String ar[])
	{
		outer.m1(20,30);
	}
}