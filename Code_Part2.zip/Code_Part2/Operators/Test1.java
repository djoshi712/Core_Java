class Test1
{
public static void main(String[] args)
{
 int x,y;
 x=++10;
 System.out.println(x);
}
}
/*
Test1.java:6: error: unexpected type
 x=++10;
     ^
  required: variable
  found:    value
1 error
*/
