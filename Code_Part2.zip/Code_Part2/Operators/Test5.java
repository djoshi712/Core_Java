class Test5
{
public static void main(String[] args)
{
 double x= 0/0.0;
 System.out.println(x);
 System.out.println(x==Double.NaN);
}
}