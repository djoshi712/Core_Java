class Test2
{
public static void main(String[] args)
{
 float f1= 10.5F;
 char ch= 'a';
 boolean b1= true;
 System.out.println(++ch);
 System.out.println(++f1);
//System.out.println(++b1);
 
}
}