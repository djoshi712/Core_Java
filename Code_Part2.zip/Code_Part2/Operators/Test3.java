class Test3
{
public static void main(String[] args)
{
 byte a=10;
 byte b=20;
 //b=b+1;
 System.out.println(a++); 
 System.out.println(a+1); 
 //byte c=a+b;
 byte c=(byte)(a+b);
 System.out.println(c);
}
}
/*
Test3.java:7: error: incompatible types: possible lossy conversion from int to byte
 byte c=a+b;
 */