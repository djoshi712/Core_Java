//https://www.baeldung.com/java-marker-interfaces#:~:text=A%20marker%20interface%20is%20an,also%20called%20a%20tagging%20interface.
//The marker or tag interface in Java interfaces with no field or methods or, in simple words empty interface 
//in java is called a marker interface. Example of marker interface is Serializable, Cloneable, and Remote 
//Example of marker interface is Serializable, Cloneable, and Remote interface.
//page 182 of java notes part 1
//Serializable is a marker interface (has no data member and method). It is used to
// mark java classes so 
//that objects of these classes may get certain capability

//https://stackoverflow.com/questions/2232759/what-is-the-purpose-of-serialization-in-java
//https://www.cs.mcgill.ca/~adenau/teaching/cs303/lecture12.pdf
/*Serialization is simply turning an existing object into a byte array. This byte array represents the class of
 the object, the version of the object, and the internal state of the object. This byte array can then be used 
 between JVM's running the same code to transmit/read the object.

Why would we want to do this?

There are several reasons:

Communication: If you have two machines that are running the same code, and they need to communicate, an easy 
way is for one machine to build an object with information that it would like to transmit, and then serialize 
that object to the other machine. 

Persistence: If you want to store the state of a particular operation in a database, it can be easily 
serialized to a byte array, and stored in the database for later retrieval.

Deep Copy: If you need an exact replica of an Object, and don't want to go to the trouble of writing your own 
specialized clone() class, simply serializing the object to a byte array, and then de-serializing it to another
 object achieves this goal.
*/
import java.io.*;
class Demo implements java.io.Serializable
{
    public int a;
    public String b;
  
    // Default constructor
    public Demo(int a, String b)
    {
        this.a = a;
        this.b = b;
    }
  
}
  
class Test
{
    public static void main(String[] args)
    {   
        Demo object = new Demo(1, "hello world");
        String filename = "file.ser";
          
        // Serialization 
        try
        {   
            //Saving of object in a file
            FileOutputStream file = new FileOutputStream(filename);
            ObjectOutputStream out = new ObjectOutputStream(file);
              
            // Method for serialization of object
            out.writeObject(object);
              
            out.close();
            file.close();
              
            System.out.println("Object has been serialized");
  
        }
          
        catch(IOException ex)
        {
            System.out.println("IOException is caught");
        }
  
  
        Demo object1 = null;
  
        // Deserialization
        try
        {   
            // Reading the object from a file
            FileInputStream file = new FileInputStream(filename);
            ObjectInputStream in = new ObjectInputStream(file);
              
            // Method for deserialization of object
            object1 = (Demo)in.readObject();
              
            in.close();
            file.close();
              
            System.out.println("Object has been deserialized ");
            System.out.println("a = " + object1.a);
            System.out.println("b = " + object1.b);
        }
          
        catch(IOException ex)
        {
            System.out.println("IOException is caught");
        }
          
        catch(ClassNotFoundException ex)
        {
            System.out.println("ClassNotFoundException is caught");
        }
  
    }
}




