/*
Method overloading:
1. If a class have multiple methods by same name but different parameters, it is known as Method Overloading.
2. Method overloading increases the readability of the program.
3. Two ways to overload the method in java	
	>By changing number of arguments
	>By changing the data type
4. Method Overloading is not possible by changing the return type of the method.
*/
class Over1
{
  void sum(int a,int b)
	  {
	  System.out.println(a+b);
	  }  
  void sum(int a,int b,int c)
	  {
	  System.out.println(a+b+c);
	  }  
  public static void main(String args[])
	  {  
	  Over1 obj=new Over1();  
	  obj.sum(10,10,10);  
	  obj.sum(20,20);  
	  }  
}
