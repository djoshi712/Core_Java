class Local 
{
	int a;
	
	public static void main(String[] args) 
	{
		//final int a=10;
		System.out.println(a);
		
	}
}

// Local vaiables are undefined prior to initialization. You don't have to initialize them at the point of declaration.