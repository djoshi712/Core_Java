/*
1. Method Overloading by changing data type of argument
*/
class Over2 
{
  void sum(int a,int b)
	{
	  System.out.println(a+b);
	}  
  void sum(double a,double b)
	{
	  System.out.println(a+b);
	}  
  void sum(double a)
	{System.out.println(a);}

}
class Main{
	public static void main(String args[]){  
  Over2 obj=new Over2();  
  obj.sum(10.5,10.5);  
  obj.sum(20,20);  
  obj.sum(10);  

}
}