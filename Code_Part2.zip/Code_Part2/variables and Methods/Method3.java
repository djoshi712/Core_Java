/* In real life scenario, method expects object
*/
class X{}			//Classes may belong to other module
class Employee{}
class Y{}
class Student{}		//Assuming classes are present here
class Method3 
{
	void m1(X x, Employee e)		//x is an object of class X
	{
		System.out.println("m1 method");
	}
	static void m2(Y y, Student s)
	{
		System.out.println("m2 method");
	}
	public static void main(String[] args) 
	{
		X x= new X();
		Employee e1= new Employee();
		Method3 obj= new Method3();
		obj.m1(x, e1);		//while pasing the object, the type of the object is important not the name of the variable
		// obj.m1(new X(), new Employee());
		Y y1=new Y();
		Student s=new Student();
		Method3.m2(y1, s);	//Method3.m2(new Y(), new Student()); 
	}
}
