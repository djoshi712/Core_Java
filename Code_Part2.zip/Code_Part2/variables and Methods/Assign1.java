class Assign1 
{
	2 instance vaiables
		static void m1()
	{
		print 2 variables
	}
	static void m2()
	{
		print 2 variables
	}
	public static void main(String[] args) 
	{
		call m1 and m2
	}
}
