// No public class, save application with any name
//save with Deepa.java compiled into (Test.class, A.class, B.class) files
// Execution: JVM executes the application. JVM loads the .class file and 
//looks for main method to start the execution
import java.lang.System;
import java.lang.String;
class Test
{
	public static void main(String[] args)  
	{
		System.out.println("Hello World!");
	}
}
class A
{
}
class B
{
}

//two predefined classes, String and System present in the package> java.Lang, we must import the packages.
// import.java.Lang.*        to import all classes of Lang package
 



