/*
1. Methods with same signature inside the class is not allowed
2. Return Type is mandatory 
*/
class Method4 
{
	void m1()	
	{
	System.out.println("A");
	}

	void m1()
	{
	System.out.println("B");
	}
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		Method4 obj=new Method4();
		obj.m1(); 
		obj.m2(); 
	}
}
