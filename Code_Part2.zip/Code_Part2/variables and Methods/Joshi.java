class Test
{
	public static void main(String[] args)  //main class
	{
		System.out.println("Hello World!");
	}
}
class A
{
	public static void main(String[] args) //main class
	{
		System.out.println("A world!");
	}
}
class B
{
	public static void main(String[] args) //main class
	{
		System.out.println("B world!");
	}
}