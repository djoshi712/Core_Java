/*
1.Java does not support inner method concept but supports inner class concept
2. Java supports inner class concept 
*/
class Method6 
{
	void m1()
	{
		System.out.println("m1 method");
		void m2() //inner method
		{
			System.out.println("Inner method");
		}

	}
	public static void main(String[] args) 
	{
		Method6 obj= new Method6();
		obj.m1();
	}	
}

// Error: Method6.java:6: error: illegal start of expression
               // void m2() //inner method