class InsVsSta
{
	int a=10; //instance variable
	static int b=20;
	public static void main(String[] args) 
	{
		Test obj1=new Test();
		System.out.println(obj1.a); 
		System.out.println(obj1.b); //not recommended, access the variable using class name
		obj1.a=100;
		obj1.b=200;
		System.out.println(obj1.a);  //100
		System.out.println(obj1.b);  //200
		Test obj2=new Test();	//we can create many objects in a class
		System.out.println(obj2.a);  //10 , for every object creation, separate memory is allocated.
		System.out.println(obj2.b); //200, In case of static variable only one memory is allocated per class for all the objects. Then, why to use static variable?
	}

}
