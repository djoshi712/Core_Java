class LocalV 
{
	public static void main(String[] args)  //main method
	{
		int a=40; 
		int b=50; 
		System.out.println(a+b);//90 
		LocalV obj=new LocalV();
		obj.m1();
	}
	void m1()
	{
		int a=10;		//local variable
		int b=20;
		System.out.println(a+b);
	}		
}
/*
1. local variables(variables declared inside the methods, constructors or block)
2. scope: within the method, constructor or block
3. memory allocated when method starts, destroyed when memory is destroyed
4. local variables are stored in stack memory 
*/