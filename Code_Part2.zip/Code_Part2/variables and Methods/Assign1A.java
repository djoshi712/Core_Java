class Assign1A 
{
	int a=1;
	double b=2.3;
	static void m1()
	{
		Assign1A obj=new Assign1A();
		System.out.println(obj.a);
		System.out.println(obj.b);
	}
	static void m2()
	{
		Assign1A obj1=new Assign1A(); //we won't be able to use the previous object here. Because, whenever the method is completed, object is destroyed thats why we must create one new object here.
		System.out.println(obj1.a);
		System.out.println(obj1.b);
	}
	public static void main(String[] args) 
	{
		Assign1A.m1(); //using static methods by using the class name(recommended)
		Assign1A.m2();
	}
}

//if 100 methods are present then do we have to create 100 objects? No. we can create one object for a class and use it throughout the class in all the methods present in the class.