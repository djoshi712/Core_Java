class Assign2 
{
	2 instatance vaiables
	2 static variables
		void m1()
	{
		   print 4 variables
	}
		static void m2()
	{
			print 4 variables
	}
	public static void main(String[] args) 
	{
		call m1 and m2
	}
}
