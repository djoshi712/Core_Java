class InstanceV 
   {
	int a=10; 
	double b=50.5; 
	public static void main(String[] args)		//static method
	{
		// System.out.println(a);				//trying to print instance variable without creating object
		 //System.out.println(b);
		InstanceV obj=new InstanceV(); 
		System.out.println(obj.a);				//static area
		System.out.println(obj.b);	
		obj.m1();								//JVM starts execution from main method, we must call all user defined method from here.
	}	
	void m1()                            //instance method
	   {
		System.out.println(a);
		System.out.println(b);	
		m2();
	   }
	void m2()
	   {
		System.out.println(a);			//Instance Area
		System.out.println(b);
	   }
   }

/*
1. Java contains two types of areas: Instance area and static area			
2. Variables declared inside the class but outside the methods, constructors or block
3. scope: within the class
4. memory allocated when the object is created and destroyed when object is destroyed
5. Access permission : static area> using object and Instance area> direct usage
*/