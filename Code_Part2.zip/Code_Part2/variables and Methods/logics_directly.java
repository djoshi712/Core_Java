class MethodEx 
{
	int a=10;
	int b=20;
	int c=a+b;
	
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		System.out.println(c); 
	}
}



















/* Basics
1. We cannnot directly write the logics inside the class
2. But declaring method and then writing the logics is perfectly 
//valid.
3. Types of method: Instance and Static
*/