//use of this inside static method 

class Method9 
{
	int x=100, y=200;					//instance variable
	static void m1(int x, int y)
	{
	System.out.println(x+y);	
	System.out.println(this.x+this.y); //using this keyword inside static method is not allowed
	}
	public static void main(String[] args) 
	{
		Method9.m1(10,20);
	}
}

