// Method Calling
class Method7 
{
	void m1()
	{
		m2();
		System.out.println("m1 method");
		m2();
	}
	void m2()
	{
		m3(10);
		System.out.println("m2 method");
	}
	void m3(int a)
	{
		System.out.println(a);
	}
	public static void main(String[] args) 
	{
		Method7 obj=new Method7();
		obj.m1();
		System.out.println("Hello World!");
	}
}
