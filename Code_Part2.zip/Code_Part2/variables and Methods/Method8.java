/*
Important: use of this keyword
If both local and non-local variables contains the same name then first priority goes to local variable.
if we want to use instance variable then use "this" keyword.
*/
class Method8 
{
	int a=10, b=20;	
	void m1(int a, int b)	
	{
	System.out.println(a+b);  //30
	System.out.println(a+b);	//300
	}
	public static void main(String[] args) 
	{
		Method8 obj= new Method8();
		obj.m1(100,200);
	}
}
