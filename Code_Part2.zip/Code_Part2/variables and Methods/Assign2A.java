class Assign2A
{
	int a=1;
	boolean b= true;
	static char c= 'D';
	static float d=1.555f;
	void m1()
	{
	System.out.println(a);
	System.out.println(b);
	System.out.println(Assign2A.c);
	System.out.println(Assign2A.d);
	}
	static void m2()
	{
	Assign2A obj=new Assign2A();
	System.out.println(obj.a);
	System.out.println(obj.b);
	System.out.println(Assign2A.c);
	System.out.println(Assign2A.d);
	}
	public static void main(String[] args) 
	{
		Assign2A obj=new Assign2A();	//calling instance method by creating the object 
		obj.m1();
		Assign2A.m2();					//calling static method using class name
	
	}
}
