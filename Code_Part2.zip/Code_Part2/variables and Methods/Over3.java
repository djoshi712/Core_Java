// Method overloading is not possible by changing the return type of the method because there may occur ambiguity
class Over3 
{
  int sum(int a,int b){
	  System.out.println(a+b);}  
  double sum(int a,int b){
	  System.out.println(a+b);}   
  public static void main(String args[]){  
  Over3 obj=new Over3();  
  obj.sum(20,20); //Compile Time Error
}
}