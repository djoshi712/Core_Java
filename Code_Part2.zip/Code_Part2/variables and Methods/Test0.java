//We cannnot directly write the logics inside the class
class method0 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
