class Method11 
{
	int m1()
	{
		return 10;
	}
	float m2()
	{
		return 12.5f;
	}
	static char m3()
	{
		return 'd';
	}
	public static void main(String[] args) 
	{
		Method11 obj=new Method11();
		int x= obj.m1();
		System.out.println("m1 method returns "+x);
		float y=obj.m2();
		System.out.println("m2 method returns"+y);
		char z=Method11.m3();
		System.out.println("m3 method returns"+z);
	}
}

