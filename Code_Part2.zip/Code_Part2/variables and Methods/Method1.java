/* Types of method
1.Instance variable: memory allocated during object creation
2.Access the instance method using objects.
3.Static method : Linked with class loading
4.Access static method by using class name.
(Example: Apply for passport)
5. modifier return_type function_name (parameter_list) throws Exception
				{

				}
		Handle the exception using throws keyword
6. Examples:
	public void m1()
	protected int m2() throws Exception
	private double m3(int a, double b)
7. Method signature: Method name+ Parameter list. Example: m1(int a)
8. method contains three parts:
Method Declaration, method implementation and method calling 
Example:m
void m1(int a)		//method declaration
 {
  //method implementation or body
 }
............................

A obj=new A();
obj.m1();	// Method calling
*/
class Method1
{
	void m1()							//instance method
	{
	System.out.println("m1 method");
	} 
	static void m2()					//static method
	{					
	System.out.println("m2 method");
	}
	public static void main(String[] args)	//static method
	{
		Method1 obj= new Method1();
		obj.m1();		//calling instance method using object
		Method1.m2();	//calling static method using class name
	}
}
