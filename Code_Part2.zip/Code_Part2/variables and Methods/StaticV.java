class StaticV 
{
	static int a=10; 
	static int b=20; 	
	public static void main(String[] args)
	{
		System.out.println(StaticV.a);
		System.out.println(StaticV.b);
		StaticV obj1= new StaticV();  //to call m1();
		obj1.m1();
	}
	void m1()			//instance area
	{
		System.out.println(StaticV.a);
		System.out.println(StaticV.b);
	}
}
 
/* 
1.Variables declared inside the class and outside the methods, constructors or block.
2.Scope: within the class
3.Memory allocated when the .class file is loaded into the memory
*/
