//1. No public class present in the source file: valid 
//2. Saving the source File containing public
import java.lang.System;
import java.lang.String;

class B
{
	public static void main(String[] args)  
	{
		System.out.println("Hello World!");
	}
}
class A
{
}
class C
{
}

//Error> java:4: error: class Test is public, should be declared in a file named Test.java



