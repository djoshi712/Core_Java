/*
1.Java does not support inner method concept but supports inner class concept
2. Java supports inner class concept 
*/
class Method5 
{
	void m1()
	{
		System.out.println("m1 method");
		void m2() //inner method
		{
			System.out.println("Inner method");
		}

	}
	public static void main(String[] args) 
	{
		Method5 obj= new Method5();
		obj.m1();
	}	
}
