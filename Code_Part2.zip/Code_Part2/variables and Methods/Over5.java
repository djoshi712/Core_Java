/*understanding command line arguments in main method
In Java args contains the supplied command-line arguments as an array of String objects.
*/
class Over5 
{
    public static void main(String[] args) {
    int a= Integer.parseInt(args[0])+Integer.parseInt(args[1]);
    System.out.println(a);
      }
 }

