/*
Operator Overloading
Java doesnot supports operator overloading. Only one overloaded operator in java is + operator
*/
class Method10 
{
	public static void main(String[] args) 
	{
		System.out.println("Learn" + "Java"); // One operator behaving in various ways:Operator Overloading
		System.out.println(10 + 20);	
		System.out.println(20+10+"Learn" + 20+30 + "Java"+ 10.23);
		int a=10, b=20, c=30;
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(a+"-----"+b+"-----"+c);
		System.out.println("a="+a + " b="+b + " c="+c);
	}
}



