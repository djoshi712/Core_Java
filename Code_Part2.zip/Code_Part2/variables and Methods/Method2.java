/* Passing arguments:
1. method parameters are local variables
*/
class Method2 
{	void m1(int a, char c)	
	{
		System.out.println("m1 method");
		System.out.println(a);
		System.out.println(c);
	}	
	static void m2(String s, double d)
	{
		System.out.println("m2 method");
		System.out.println(s);
		System.out.println(d);
	}
	public static void main(String[] args) 
	{
		Method2 obj=new Method2();
		obj.m1(10, 'd');	//while passing the arguments, the order and number of parameters are important
		Method2.m2("Java", 21.54); //In real time scenario, the method expects the objects not the primitive data types.
	}
}
