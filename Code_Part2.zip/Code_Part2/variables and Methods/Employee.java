class Employee 
{
	int eid;				//Instance Variable
	String eName;			//Instance Variable
	String eCompany;	
	public static void main(String[] args) 
	{
			Employee Obj1= new Employee();
			obj1.eid= 40001464;
			obj1.eName="Tripti";
			Obj1.eCompany="UPES";
			system.out.println(obj1.eid);
			system.out.println(obj1.eName);
			system.out.println(obj1.eCompany);
			Employee Obj2= new Employee();
			obj2.eid= 40001463;
			obj2.eName="Vidushi";
			Obj2.ecompany="UPES";
			Employee Obj3= new Employee();
			obj3.eid= 40001465;
			obj3.eName="Nitika";
			Obj3.ecompany="UPES";	
		
	}
}
