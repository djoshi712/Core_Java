class StaticT 
{
	static int a=10;
	public static void main(String[] args) 
	{
		StaticT obj1=new StaticT();
		System.out.println(obj1.a); 
		System.out.println(StaticT.a); //by using class name(Recommended approach)Mmeory created during the class file loading
		   //by creating object
		System.out.println(a);	
	}
}

