//In real time we retun object as return value
class Method11Example2 
{
	
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
	}
}
