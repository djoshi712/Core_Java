/*
1.overloading main() method
We can overload the main method in Java. But the program doesn�t
execute the overloaded main method. when we run program, we need to call the overloaded  main method from the actual main method only.
*/
class Over4 
{        
  // Normal main()
  public static void main(String[] a) {
    System.out.println("Hi (from actual main)");
    Over4.main("Not real main");
  }     
  // Overloaded main methods
  public static void main(String a1) {
    System.out.println("Hi," + a1);
    Over4.main("Not","Real");
  }
  public static void main(String a1, String a2) {
    System.out.println("Hi, " + a1 + ", " + a2);
  }
}
