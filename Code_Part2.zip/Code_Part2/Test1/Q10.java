		 class A
		{
			int a;
			int b;   
		A(int a, int b) 
		{
			a=a;
			b=b;       
		} 
		public static void main(String[] args) 
		{     
			A obj = new A(10, 20);
			System.out.println(obj.a);
			System.out.println(obj.b);
		}
		}
