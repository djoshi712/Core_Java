public class Q13{
    int a;
    int b;   
Q13(int a, int b) {
    a=a;
    b=b;       } 
public static void main(String[] args) {     
    Q13 obj = new Q13(10, 20);
     System.out.println(obj.a);
     System.out.println(obj.b);}}
