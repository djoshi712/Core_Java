class Q16{ 
static int a=10;
static int b=20;
 public static void main(String [] args){ 
 static int c=10;
 System.out.println(a);
 System.out.println(c); }}
