class Q1
{
boolean x= true;
boolean y= false;
public static void main(String[] args)
{
	Q1 obj= new Q1();
	if(obj.x!=obj.y!=obj.y)
	 {
      System.out.println("true");
	 }
     else     
	 { 
		System.out.println("false"); 
	 } 
}
}