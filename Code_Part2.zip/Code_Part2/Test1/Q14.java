public abstract class Q14 {
     public static void main(String args[]){
     Q14 obj = new Q14();       
 }} 
