class Q4
{
	public static void main(String[] args)
	{
	m1();
	}
	static void m1()
	{
	System.out.println("Hi");
	return;
	}
}