package package1;
/*class Test1
{
	public void m1()
		{
		System.out.println("Test1 class");
		}
	
}*/

//make class public
/*public class Test1
{
	public void m1()
		{
		System.out.println("Test1 class");
		}
	
}*/

default class Test1
{
	public void m1()
		{
		System.out.println("Test1 class");
		}
	
}
