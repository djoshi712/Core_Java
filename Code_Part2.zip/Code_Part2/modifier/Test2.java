package package2;
import package1.Test1;
class Test2 
{
	public static void main(String[] args) 
	{
		Test1 obj= new Test1();
		obj.m1();
		}
}
