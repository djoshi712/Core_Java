//xxxValue() method, used to convert wrapper class to primitive types
class xxxvalue
{
/*
Types: 
public byte byteValue();
public short shortValue();
public int intValue();
public long longValue();
public float floatValue();
public double doubleValue();

applicable for all Number type wrapper classes
*/
public static void main(String[] args)
{
Integer i1= new Integer(130); //wrapped to Integer object
System.out.println(i1.byteValue());	//trying to get primitive value
System.out.println(i1.shortValue());
System.out.println(i1.intValue());
System.out.println(i1.floatValue());
System.out.println(i1.doubleValue());
//public char charValue();
Character c= new Character('v');
char d= c.charValue();
System.out.println(d);
}
}
