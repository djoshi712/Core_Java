//valueOf method
// valueOf() method used to create Wrapper object for given primitive or String
class valueof
{
	public static void main(String[] args)
	{
//Type 1: public static wrapper valueOf(primitive p)
//applicable to all wrapper class
		Integer i7= Integer.valueOf(10);
		Float f9 = Float.valueOf(10);
		Character ch= Character.valueOf('j');

//Type 2: public static wrapper valueOf(String s)
//applicable to all wrapper class except Character class
		Integer i1= new Integer("10"); 		//using constructors 
		Integer i2= Integer.valueOf("10");	//using utilty method
		Double d= Double.valueOf("10.2");
		Boolean b= Boolean.valueOf("10");
		System.out.println(i1);
		System.out.println(i2);
		System.out.println(d);
		System.out.println(b);
		//Character i3= Character.valueOf("10");
		
//Type 3: public static wrapper valueOf(String s, int radix or base)
//applicable only for integral types: Byte, Short, Intger, Long
		Integer i4= Integer.valueOf("1111", 2);
		System.out.println(i4); 
		Integer i5= Integer.valueOf("1111", 16);
		System.out.println(i5); 
		Integer i6= Integer.valueOf("1111", 37);			
	}
}



		
		
		