/*  class auto
{
	public static void main(String[] args)
	{
		Integer i= 10; //compiler converts int to Integer automatcally and replaced with the below line
		//Integer i= Integer.valueOf(10);
		Integer i1= new Integer(10);
		int i= i1; //compiler converts integer to int automatically using autunboxing and replaced by the given line
		//int i= i1.intValue();
	}
}  */


/* class auto
{
	static Integer I= 10; 
	public static void main(String[] args)
	{
		 int i=I;	
		 m1(i);
	}
	public static void m1(Integer k)	
	{
		int m=k;		
		System.out.println(m);
	}
}	
  */

/*   class auto
{
	public static void main(String[] args)
	{
		Integer x= 10;
		Integer y=x;
		x++;
		System.out.println(x);
		System.out.println(y);
		System.out.println(x==y);
		
	}	
}    */

  class auto
{
	public static void main(String[] args)
	{
		Integer x= new Integer(10);
		Integer y= new Integer(10);
		System.out.println(x==y); //
		
		Integer x1= new Integer(10);
		Integer y1= 10;
		System.out.println(x1==y1); 
		
		Integer x2= 10;
		Integer y2= 10;
		System.out.println(x2==y2); 
		
		Integer x3= 100;
		Integer y3= 100;
		System.out.println(x3==y3); 
		
		Float f1= 10.2f;
		Float f2= 10.2f;
		System.out.println(f1==f2); 
		
		Integer x4= 1000;
		Integer y4= 1000;
		System.out.println(x4==y4);	 
		
	}	
}  


//New Integer vs valueOf
//Integer.valueOf implements a cache for the values -128 to +127. 
//to provide support for autobxoing , a buffer of wrapper objects will be created 
//at the time of wrapper class loading

/* 
class Integer{
	static{
		//buffer of objects created and the range is -128 to 127
	} */

