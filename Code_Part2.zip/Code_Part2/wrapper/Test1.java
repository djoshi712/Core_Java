import java.util.ArrayList;
class Test1
{
public static void main(String[] args) 
{
ArrayList l= new ArrayList(10);
//l.add(10);
Integer i= new Integer(10);
l.add(i);
}
}
