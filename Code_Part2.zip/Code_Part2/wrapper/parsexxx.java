//convert string to primitive
//present in every wrapper class except character class 
// public static primitive parsexxx(String a);
//public static primitive parsexxx(String a, int radix)> available only in Integral classes
class parsexxx
{
	public static void main(String[] args)
	{
		int a= Integer.parseInt("10");
		boolean b= Boolean.parseBoolean("false");
		double c= Double.parseDouble("10.6");
		int d= Integer.parseInt("1111", 2);
		System.out.println(d);


}
