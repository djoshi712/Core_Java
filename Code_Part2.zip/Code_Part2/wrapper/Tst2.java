import java.util.ArrayList;
import java.util.Iterator;

public class Tst2 {
    
    public static void main(String[] args) { 
 
        // ArrayList Example   
  
        ArrayList<Integer> arrlistobj = new ArrayList<Integer>();
        arrlistobj.add(10); //arrlistobj.add()
        arrlistobj.add(new Integer(20));
	//Converted int primitive to Integer object and added to arraylistobject
        Iterator it = arrlistobj.iterator();
        System.out.print("ArrayList object output :");  
        while(it.hasNext())         
          System.out.print(it.next() + " ");
             
          
         
        // Array Example
 
        String[] arrayobj = new String[3];
        arrayobj[0]= "Love yourself";  
        arrayobj[1]= "Alive is awesome";
        arrayobj[2]= "Be in Present"; 
        System.out.print("Array object output :");
        for(int i=0; i < arrayobj.length ;i++)
        System.out.print(arrayobj[i] + " ");   
 
 }
}