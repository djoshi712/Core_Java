//toString: to convert wrapper object or primitive to string
//public String toString() : Every wrapper class contains this method 
//to convert Wrapper Object to String type. 
class tostring
{
	public static void main(String[] args)
	{
		Integer i= new Integer(10);
		String s= i.toString();
		System.out.println(i +"..."+ i.getClass());
		System.out.println(s +"..."+ s.getClass());
//public static String toString(primitive p);
		String s1= Integer.toString(20);
		System.out.println(s1 +"..."+ s1.getClass());
		String s2= Character.toString('a');
		System.out.println(s2 +"..."+ s2.getClass());
	}