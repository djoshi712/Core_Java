//Basics
//The objective of Wrapper class is to define several utility methods 
//which are required for the primitive types. 
/* object oriented programming is all about objects. The eight primitive data types
 byte, short, int, long, float, double, char and boolean are not objects, 
 Wrapper classes are used for converting primitive data types into objects, 
 like int to Integer etc. 
For example: While working with collections in Java, we use generics for type
 safety like this: ArrayList<Integer> instead of this ArrayList<int>. 
 The Integer is a wrapper class of int primitive type. We use wrapper class in
 this case because data structures needs objects not primitives. 
  use them in collections API. On the other hand the wrapper objects hold much more 
memory compared to primitive types. So use primitive types when you need efficiency and use wrapper class when you need objects instead of primitive types.
 */
class Test4
{
public static void main(String[] agrs) 
{
	Integer i1= new Integer(10);
	Integer i2= new Integer("10");
	//Integer i3= new Integer("ten");
	//Integer i4= new Integer(10.5);
	Float f1= new Float(10.4);
	Float f2= new Float(10.4f);
	Float f4= new Float("10.4f");
	System.out.println(f4); //10.4
	Float f3= new Float("10.4");
	Character ch= new Character('d');
	//Character ch= new Character("d");
	Boolean b1= new Boolean(true);
	Boolean b2= new Boolean(false);
	//Boolean b3= new Boolean(tRue);
	//Boolean b4= new Boolean(falSe);
	Boolean b5= new Boolean("no");
	Boolean b6= new Boolean("yes");
	System.out.println(b6.equals(b5)); //true
	System.out.println(b5); //false
	System.out.println(b6); //false
	Boolean b7= new Boolean("TrUe");
	Boolean b8= new Boolean("true");
	Boolean b9= new Boolean("FalsE");
	Boolean b10= new Boolean("false");
	System.out.println(b7.equals(b8));
	System.out.println(b9.equals(b10));	 
}
}

//case insensitive string is treated as true otherwise false



	

	