/* use of forName method of class "Class"
load B and C class file dynamically into memory during runtime using one method called 
forName is a static method present in class "Class"
*/
class A 
{
	static
		{
		System.out.println("static block A");
		}	
	public static void main(String[] args) throws ClassNotFoundException 
		{
		Class.forName("B"); //to execute the static blocks present in B class without using main method use "forname" method
		Class.forName("C");
		}
}
