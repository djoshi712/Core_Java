/* Static blocks:  used to initialize static variables and to write the logics
Steps performed by JVM:
1. JVM loads correspponding .class file byte code into memory. then static blocks are executed
2. JVM calls main method to start the execution. 
Important: > upto 1.5 version, we can write static blocks and will be executed during .class file loading. From 1.6 version onwards, in order to execute the static blocks only, main method is mandatory inside the class. 
> onlyone time .class file is loaded, it means only one time static blocks are executed.
*/
class Test1 {
	int a;
	
	{a=10;	
	System.out.println(a);
	}
	{	System.out.println("instance block-2");
	}
	static{
			System.out.println("static block-1");}
	static{
			System.out.println("static block-2");}
	Test1(){
			}
	Test1(int a){
		this.a=a;
			System.out.println();}
	public static void main(String[] args) {
		new Test1();
		new Test1(20);
	}
}
