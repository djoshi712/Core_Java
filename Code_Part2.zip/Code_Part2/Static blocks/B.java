class B 
{
	static
	{
		System.out.println("static block B ");
	}
}
