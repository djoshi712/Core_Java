// static blocks are used to initialize static variable
class Test2 
{
	static int a;
	static{
		a=10;
		System.out.println("Test2.a");
	}
	public static void main(String[] args) 
	{
		
	}
}
