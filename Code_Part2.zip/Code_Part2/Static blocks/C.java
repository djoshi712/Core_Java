class C 
{
	static{
		System.out.println("static block C");
		}
}
